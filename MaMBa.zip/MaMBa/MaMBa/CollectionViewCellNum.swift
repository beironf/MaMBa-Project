//
//  CollectionViewCellInt.swift
//  MaMBa
//
//  Created by Fredrik Beiron on 2017-06-07.
//  Copyright © 2017 Fredrik Beiron. All rights reserved.
//

import UIKit

class CollectionViewCellNum: UICollectionViewCell {

    @IBOutlet weak var result: UILabel!
    @IBOutlet weak var attemptNr: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
