//
//  ViewController2.swift
//  BollApp2
//
//  Created by Fredrik Beiron on 11/02/16.
//  Copyright © 2016 Fredrik Beiron. All rights reserved.
//

import UIKit

class ViewController2: UIViewController {

    @IBOutlet weak var ovn1: UIImageView!
    @IBOutlet weak var ovn2: UIImageView!
    @IBOutlet weak var ovn3: UIImageView!
    @IBOutlet weak var ovn4: UIImageView!
    @IBOutlet weak var ovn5: UIImageView!
    @IBOutlet weak var ovn6: UIImageView!
    
    @IBOutlet weak var ovnNr1: UILabel!
    @IBOutlet weak var ovnNr2: UILabel!
    @IBOutlet weak var ovnNr3: UILabel!
    @IBOutlet weak var ovnNr4: UILabel!
    @IBOutlet weak var ovnNr5: UILabel!
    @IBOutlet weak var ovnNr6: UILabel!
    
    @IBOutlet weak var ovnLabel1: UILabel!
    @IBOutlet weak var ovnLabel2: UILabel!
    @IBOutlet weak var ovnLabel3: UILabel!
    @IBOutlet weak var ovnLabel4: UILabel!
    @IBOutlet weak var ovnLabel5: UILabel!
    @IBOutlet weak var ovnLabel6: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
