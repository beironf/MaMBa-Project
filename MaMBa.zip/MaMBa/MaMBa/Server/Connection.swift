//
//  Connection.swift
//  GoFlow
//
//  Created by Fredrik Beiron on 05/05/16.
//  Copyright © 2016 Fredrik Beiron. All rights reserved.
//

import Foundation

protocol ConnectionDelegate {
    func serverDidConnect(_ sender: Connection, stream: Stream)
    func serverDidDisconnect(_ sender: Connection, s: String)
    func serverDidReceiveValue(_ sender: Connection, dataMsg: String)
    func serverIsOffline(_ sender: Connection, s: String)
}

class Connection: NSObject, StreamDelegate {
    var delegate: ConnectionDelegate?
    
    var host:String?
    var port:Int?
    var inputStream: InputStream?
    var outputStream: OutputStream?
    var dataToSend: String?
    
    func connect(_ host: String, port: Int) {
        
        self.host = host
        self.port = port
        
        Stream.getStreamsToHost(withName: host, port: port, inputStream: &inputStream, outputStream: &outputStream)
        
        if inputStream != nil && outputStream != nil {
            
            // Set delegate
            inputStream!.delegate = self
            outputStream!.delegate = self
            
            // Schedule
            inputStream!.schedule(in: .main, forMode: RunLoopMode.defaultRunLoopMode)
            outputStream!.schedule(in: .main, forMode: RunLoopMode.defaultRunLoopMode)
            
            //print("Start open()")
            
            // Open!
            inputStream!.open()
            outputStream!.open()
        }
    }
    
    func sendData(_ data: String) {
        self.dataToSend = data
        self.stream(outputStream!, handle: Stream.Event.hasSpaceAvailable)
    }
    
    func stream(_ aStream: Stream, handle eventCode: Stream.Event) {
        switch eventCode {
        case Stream.Event.errorOccurred:
            //print("input: ErrorOccurred: \(aStream.streamError?.description)")
            delegate?.serverIsOffline(self, s: "Server offline")
            break
        case Stream.Event():
            //print("input: No events occured")
            delegate?.serverIsOffline(self, s: "Server offline")
            break
        case Stream.Event.endEncountered:
            //print("input: Connection ended")
            delegate?.serverDidDisconnect(self,s: "Server disconnected")
            break
        case Stream.Event.openCompleted:
            //print("input: OpenCompleted")
            delegate?.serverDidConnect(self,stream: aStream)
            break
        case Stream.Event.hasBytesAvailable:
            //print("input: HasBytesAvailable")
            var buffer = [UInt8](repeating: 0, count: 4096)
            if aStream == inputStream {
                while (inputStream!.hasBytesAvailable){
                    let len = inputStream!.read(&buffer, maxLength: buffer.count)
                    if(len > 0){
                        if let input = NSString(bytes: &buffer, length: buffer.count, encoding: String.Encoding.utf8.rawValue) {
                            let trimmedInput: String = (input as String).trimmingCharacters(
                                in: CharacterSet.whitespacesAndNewlines)
                            delegate?.serverDidReceiveValue(self, dataMsg: trimmedInput)
                        }
                    }
                }
            }
            break
        case Stream.Event.hasSpaceAvailable:
            //print("output: HasSpaceAvailable")
            if let s: String = dataToSend {
                let data: Data = s.data(using: String.Encoding.utf8)!
                outputStream!.write((data as NSData).bytes.bindMemory(to: UInt8.self, capacity: data.count), maxLength: data.count)
            }
            dataToSend = nil
            break
        default:
            break
        }
    }
}
