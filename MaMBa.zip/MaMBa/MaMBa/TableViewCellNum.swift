//
//  TableViewCellInt.swift
//  MaMBa
//
//  Created by Fredrik Beiron on 2017-04-17.
//  Copyright © 2017 Fredrik Beiron. All rights reserved.
//

import UIKit

protocol TableViewCellNumDelegate {
    // indicates that the given item has been deleted
    func tableItemDeleted(_ tableItem: MyTableType)
}

class TableViewCellNum: UITableViewCell {
    
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var result: UILabel!
    @IBOutlet weak var imageEquipment: UIImageView!
    @IBOutlet weak var imageExercise: UIImageView!
    @IBOutlet weak var resultText: UILabel!
    // Data View
    @IBOutlet weak var ovnLabel: UILabel!
    @IBOutlet weak var label1: UILabel!
    @IBOutlet weak var label2: UILabel!
    @IBOutlet weak var label3: UILabel!
    @IBOutlet weak var label4: UILabel!
    @IBOutlet weak var label5: UILabel!
    @IBOutlet weak var label6: UILabel!
    @IBOutlet weak var label7: UILabel!
    @IBOutlet weak var label8: UILabel!
    @IBOutlet weak var label9: UILabel!
    @IBOutlet weak var label10: UILabel!
    @IBOutlet weak var label11: UILabel!
    @IBOutlet weak var label12: UILabel!
    @IBOutlet weak var label13: UILabel!
    @IBOutlet weak var label14: UILabel!
    @IBOutlet weak var label15: UILabel!
    @IBOutlet weak var label16: UILabel!
    @IBOutlet weak var label17: UILabel!
    @IBOutlet weak var label18: UILabel!
    @IBOutlet weak var label19: UILabel!
    @IBOutlet weak var label20: UILabel!
    
    var originalCenter = CGPoint()
    var deleteOnDragRelease = false
    var delegate: TableViewCellDelegate?
    var tableItem: MyTableType?
    var crossLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        let recognizer = UIPanGestureRecognizer(target: self, action: #selector(self.handlePan(_:)))
        recognizer.delegate = self
        addGestureRecognizer(recognizer)
        
        // tick and cross labels for context cues
        crossLabel = createCueLabel()
        addSubview(crossLabel)
    }
    
    // utility method for creating the contextual cues (delete label, cross)
    func createCueLabel() -> UILabel {
        let label = UILabel(frame: CGRect.null)
        label.textColor = UIColor.clear
        label.font = UIFont.boldSystemFont(ofSize: 40.0)
        label.backgroundColor = UIColor.red
        label.text = "\u{2717}" // 2717
        label.textAlignment = .right
        label.alpha = CGFloat(0.0)
        return label
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        crossLabel.frame = CGRect(x: -bounds.size.width, y: 0,
                                  width: bounds.size.width, height: bounds.size.height)
    }
    
    //MARK: - horizontal pan gesture methods (delete swipe)
    @objc func handlePan(_ recognizer: UIPanGestureRecognizer) {
        if recognizer.state == .began {
            // when the gesture begins, record the current center location
            originalCenter = center
        }
        if recognizer.state == .changed {
            let translation = recognizer.translation(in: self)
            center = CGPoint(x: originalCenter.x + translation.x, y: originalCenter.y)
            // has the user dragged the item far enough to initiate a delete/complete?
            deleteOnDragRelease = frame.origin.x > frame.size.width / 2.0
        }
        if recognizer.state == .ended {
            // the frame this cell had before user dragged it
            let originalFrame = CGRect(x: 0, y: frame.origin.y,
                                       width: bounds.size.width, height: bounds.size.height)
            if !deleteOnDragRelease {
                // if the item is not being deleted, snap back to the original location
                UIView.animate(withDuration: 0.2, animations: {self.frame = originalFrame})
            }
            if deleteOnDragRelease {
                if delegate != nil && tableItem != nil {
                    UIView.animate(withDuration: 0.2, animations: {self.frame = originalFrame})
                    // ask the delegate if this item should be deleted
                    delegate!.showShouldTableItemBeDeleted(tableItem!)
                }
            }
        }
        // fade the contextual clues
        let cueAlpha = fabs(frame.origin.x) / (frame.size.width / 2.0)
        crossLabel.alpha = cueAlpha
        // indicate when the user has pulled the item far enough to invoke the given action
        crossLabel.textColor = deleteOnDragRelease ? UIColor.white : UIColor.clear
    }
    
    override func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
        if let panGestureRecognizer = gestureRecognizer as? UIPanGestureRecognizer {
            let translation = panGestureRecognizer.translation(in: superview!)
            if fabs(translation.x) > fabs(translation.y) {
                let vel: CGPoint = panGestureRecognizer.velocity(in: self.forFirstBaselineLayout)
                if vel.x > 0 {
                    return true
                }
            }
            return false
        }
        return false
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
