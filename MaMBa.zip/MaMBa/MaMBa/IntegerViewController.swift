//
//  IntegerViewController.swift
//  GoFlow
//
//  Created by Fredrik Beiron on 2017-04-07.
//  Copyright © 2017 Fredrik Beiron. All rights reserved.
//

import UIKit
import AVFoundation // Ljud
//import AudioToolbox // vibrate

class IntegerViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate, UITextFieldDelegate, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    // --------------------------------------------------------------------------------------
    // ----------------------------------- Variables ----------------------------------------
    // --------------------------------------------------------------------------------------
    
    @IBOutlet weak var cancel: UIImageView!
    @IBOutlet weak var save: UIImageView!
    @IBOutlet weak var exerciseTitle: UILabel!
    @IBOutlet weak var pickerView: UIPickerView!
    @IBOutlet weak var increase: UIImageView!
    @IBOutlet weak var decrease: UIImageView!
    @IBOutlet weak var handImage: UIImageView!
    @IBOutlet weak var footImage: UIImageView!
    @IBOutlet weak var racketImage: UIImageView!
    @IBOutlet weak var clubImage: UIImageView!
    @IBOutlet weak var IDInput: UIPickerView!
    @IBOutlet weak var nextButton: UIButton!
    @IBOutlet weak var prevButton: UIButton!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var nextArrow: UIImageView!
    @IBOutlet weak var prevArrow: UIImageView!
    @IBOutlet weak var nextText: UILabel!
    @IBOutlet weak var prevText: UILabel!
    @IBOutlet weak var startTime: UIImageView!
    @IBOutlet weak var timerLabel: UILabel!
    @IBOutlet weak var directionLabel: UILabel!
    @IBOutlet weak var directionButton: UIButton!
    
    var audioPlayer = AVAudioPlayer()  // Ljud
    var timerIsActive: Bool = false
    var isTimerExcercise: Bool?
    var timerHasBeenActive: Bool = false

    var shouldSave: Bool = false
    var attempt: Int = 1
    
    var exerciseTitleVar: String?
    
    // Variables for equipment
    var equipmentChoice: Int?           // hand = 1, foot = 2, racket = 3, club = 4
    var activeEquipments: [[Int]]?        // [1, 1, 0, 0] => only hand and foot can be chosen in this exercise
    var shouldChangeEquipment: [Bool]?
    
    var nameID: Int?
    var exerciseNr: Int?
    var nrOfAttempts: Int?
    var idArray: [Int]?
    var pickerArray: [Int]?
    
    var isMiniGolf: Bool?
    
    var playTimer: Timer?
    var clockTimer: Timer?
    var timerValue: Int = 20
    
    var host: String?
    var activeMenuWindow: Int?
    
    var results: [Double]?
    
    let equipmentsTxt = ["hand", "fot", "rack", "klubba", "armbåge", "lår", "slagträ", "huvud"]
    
    
    
    // --------------------------------------------------------------------------------------
    // ----------------------------------- View did load ------------------------------------
    // --------------------------------------------------------------------------------------
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.layoutIfNeeded()
        
        self.pickerView.dataSource = self;
        self.pickerView.delegate = self;
        
        self.IDInput.dataSource = self;
        self.IDInput.delegate = self;
        
        self.collectionView.dataSource = self;
        self.collectionView.delegate = self;
        
        collectionView.register(UINib(nibName: "CollectionViewCellNum", bundle: nil), forCellWithReuseIdentifier: "collectionCellNum")
        
        
        do {  // Ljud
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "beep2", ofType:"mp3")!))
            audioPlayer.prepareToPlay()
        }
            
        catch {
            //print(error)
        }
        
        
        let tapGestureCancel = UITapGestureRecognizer(target: self, action: #selector(self.cancelPressed))
        self.cancel.addGestureRecognizer(tapGestureCancel)
        
        let tapGestureSave = UITapGestureRecognizer(target: self, action: #selector(self.savePressed))
        self.save.addGestureRecognizer(tapGestureSave)
        
        let tapGestureHand = UITapGestureRecognizer(target: self, action: #selector(self.handPressed))
        self.handImage.addGestureRecognizer(tapGestureHand)
        
        let tapGestureFoot = UITapGestureRecognizer(target: self, action: #selector(self.footPressed))
        self.footImage.addGestureRecognizer(tapGestureFoot)
        
        let tapGestureRacket = UITapGestureRecognizer(target: self, action: #selector(self.racketPressed))
        self.racketImage.addGestureRecognizer(tapGestureRacket)
        
        let tapGestureClub = UITapGestureRecognizer(target: self, action: #selector(self.clubPressed))
        self.clubImage.addGestureRecognizer(tapGestureClub)
        
        let tapGestureIncrease = UITapGestureRecognizer(target: self, action: #selector(self.increasePressed))
        self.increase.addGestureRecognizer(tapGestureIncrease)
        
        let tapGestureDecrease = UITapGestureRecognizer(target: self, action: #selector(self.decreasePressed))
        self.decrease.addGestureRecognizer(tapGestureDecrease)
        
        let tapGestureNext = UITapGestureRecognizer(target: self, action: #selector(self.nextPressed))
        self.nextButton.addGestureRecognizer(tapGestureNext)
        
        let tapGesturePrev = UITapGestureRecognizer(target: self, action: #selector(self.prevPressed))
        self.prevButton.addGestureRecognizer(tapGesturePrev)
        
        let tapGestureStart = UITapGestureRecognizer(target: self, action: #selector(self.startTimePressed))
        self.startTime.addGestureRecognizer(tapGestureStart)
        
        let tapGestureDirection = UITapGestureRecognizer(target: self, action: #selector(self.directionPressed))
        self.directionButton.addGestureRecognizer(tapGestureDirection)
        
    
        exerciseTitle.text = exerciseTitleVar
        IDInput.selectRow(nameID!, inComponent: 0, animated: true)
        
        results = [Double](repeating: 0, count: nrOfAttempts!)
        
        if isTimerExcercise! == false {
            startTime.alpha = 0.3
            timerLabel.alpha = 0
            timerHasBeenActive = true
        }
        
        if isMiniGolf! {
            directionLabel.text = "höger"
        } else {
            directionButton.isUserInteractionEnabled = false
            directionLabel.text = ""
        }
        
        prevText.text = ""
        prevArrow.alpha = 0.0
        if isTimerExcercise! {
            nextText.alpha = 0.3
            nextArrow.alpha = 0.3
        }
        
        self.updateEquipments(setToActive: -1)
    }
    
    
    
    func updateEquipments(setToActive: Int) {
        let equipmentImageViews: [UIImageView] = [handImage, footImage, racketImage, clubImage]
        let equipmentImagesON: [UIImage] = [#imageLiteral(resourceName: "handON"),#imageLiteral(resourceName: "footON"),#imageLiteral(resourceName: "racketON"),#imageLiteral(resourceName: "clubON"),#imageLiteral(resourceName: "elbowON"),#imageLiteral(resourceName: "legON"),#imageLiteral(resourceName: "batON"),#imageLiteral(resourceName: "headON")]
        let equipmentImages: [UIImage] = [#imageLiteral(resourceName: "hand"),#imageLiteral(resourceName: "foot"),#imageLiteral(resourceName: "racket"),#imageLiteral(resourceName: "club"),#imageLiteral(resourceName: "elbow"),#imageLiteral(resourceName: "leg"),#imageLiteral(resourceName: "bat"),#imageLiteral(resourceName: "head")]
        let activeID = idArray![IDInput.selectedRow(inComponent: 0)]-1
        var onIsUsed = false
        for i in 0...equipmentImageViews.count-1 {
            if activeEquipments![activeID][i] == 0 {
                equipmentImageViews[i].alpha = 0.2
                if shouldChangeEquipment![i] {
                    equipmentImageViews[i].image = equipmentImages[i+4]
                } else {
                    equipmentImageViews[i].image = equipmentImages[i]
                }
            } else {
                equipmentImageViews[i].alpha = 1.0
                if shouldChangeEquipment![i] {
                    if (onIsUsed || (i < setToActive)) {
                        equipmentImageViews[i].image = equipmentImages[i+4]
                    } else if setToActive == i || setToActive < 0 {
                        equipmentImageViews[i].image = equipmentImagesON[i+4]
                        self.equipmentChoice! = i+1
                        onIsUsed = true
                    }
                } else {
                    if (onIsUsed || (i < setToActive)) {
                        equipmentImageViews[i].image = equipmentImages[i]
                    } else if setToActive == i || setToActive < 0 {
                        equipmentImageViews[i].image = equipmentImagesON[i]
                        self.equipmentChoice! = i+1
                        onIsUsed = true
                    }
                }
            }
        }
    }
    
    
    // ---------------------------------------------------------------------------------------
    // ---------------------------------------- Button pressed methods -----------------------
    // ---------------------------------------------------------------------------------------
    
    /*func startPressed() {
        Timer.scheduledTimer(timeInterval: 20, target: self, selector: #selector(self.Play), userInfo: nil, repeats: false)
    
    }*/
    
    @objc func cancelPressed() {
        if timerIsActive == false {
            self.showCancelConfirmation()
            // self.performSegue(withIdentifier: "showMenuFromInteger", sender: self)
        }
    }
    
    @objc func savePressed() {
        if !timerIsActive {
            if attempt > nrOfAttempts! {
                self.showConfirmation()
            } else {
                self.showNotFinishedWithExercise()
            }
        }
    }
    
    @objc func handPressed() {
        let activeID = idArray![IDInput.selectedRow(inComponent: 0)]-1
        if attempt <= nrOfAttempts! && activeEquipments![activeID][0] == 1 {
            self.updateEquipments(setToActive: 0)
            equipmentChoice = 1
        }
    }
    
    @objc func footPressed() {
        let activeID = idArray![IDInput.selectedRow(inComponent: 0)]-1
        if attempt <= nrOfAttempts! && activeEquipments![activeID][1] == 1 {
            self.updateEquipments(setToActive: 1)
            equipmentChoice = 2
        }
    }
    
    @objc func racketPressed() {
        let activeID = idArray![IDInput.selectedRow(inComponent: 0)]-1
        if attempt <= nrOfAttempts! && activeEquipments![activeID][2] == 1 {
            self.updateEquipments(setToActive: 2)
            equipmentChoice = 3
        }
    }
    
    @objc func clubPressed() {
        let activeID = idArray![IDInput.selectedRow(inComponent: 0)]-1
        if attempt <= nrOfAttempts! && activeEquipments![activeID][3] == 1 {
            self.updateEquipments(setToActive: 3)
            equipmentChoice = 4
        }
    }
    
    @objc func increasePressed() {
        if attempt <= nrOfAttempts! && pickerView.selectedRow(inComponent: 0) < pickerArray!.count {
            //AudioServicesPlayAlertSound(SystemSoundID(kSystemSoundID_Vibrate))
            let activeRow = pickerView.selectedRow(inComponent: 0)
            pickerView.selectRow(activeRow+1, inComponent: 0, animated: true)
        }
    }
    
    @objc func decreasePressed() {
        if attempt <= nrOfAttempts! && pickerView.selectedRow(inComponent: 0) > 0 {
            //AudioServicesPlayAlertSound(SystemSoundID(kSystemSoundID_Vibrate))
            let activeRow = pickerView.selectedRow(inComponent: 0)
            pickerView.selectRow(activeRow-1, inComponent: 0, animated: true)
        }
    }
    
    @objc func nextPressed() {
        if attempt <= nrOfAttempts! && timerIsActive == false && timerHasBeenActive == true {
            let cell = (collectionView!.cellForItem(at: IndexPath(row: attempt-1, section: 0)) as! CollectionViewCellNum)
            cell.result.text = String(pickerArray![pickerView.selectedRow(inComponent: 0)])
            results![attempt-1] = Double(pickerArray![pickerView.selectedRow(inComponent: 0)])
            pickerView.selectRow(0, inComponent: 0, animated: true)
            if attempt == nrOfAttempts! {
                nextText.text = ""
                nextArrow.alpha = 0.0
                pickerView.isUserInteractionEnabled = false
                pickerView.alpha = 0.3
                increase.alpha = 0.3
                decrease.alpha = 0.3
                startTime.alpha = 0.3
            } else if isTimerExcercise! {
                nextText.alpha = 0.3
                nextArrow.alpha = 0.3
            }
            prevText.text = "Ångra"
            prevArrow.alpha = 1.0
            attempt = attempt + 1
            if isTimerExcercise! { timerHasBeenActive = false }
        }
    }
    
    @objc func prevPressed() {
        if attempt > 1 {
            let cell = (collectionView!.cellForItem(at: IndexPath(row: attempt-2, section: 0)) as! CollectionViewCellNum)
            cell.result.text = ""
            results![attempt-2] = 0.0
            pickerView.selectRow(0, inComponent: 0, animated: true)
            if attempt == nrOfAttempts!+1 {
                nextText.text = "Nästa"
                nextArrow.alpha = 1.0
                pickerView.isUserInteractionEnabled = true
                pickerView.alpha = 1.0
                increase.alpha = 1.0
                decrease.alpha = 1.0
                if isTimerExcercise! {
                    startTime.alpha = 1.0
                }
            } else if attempt == 2 {
                prevText.text = ""
                prevArrow.alpha = 0.0
            }
            if isTimerExcercise! {
                nextText.alpha = 0.3
                nextArrow.alpha = 0.3
            }
            attempt = attempt - 1
            if isTimerExcercise! { timerHasBeenActive = false }
        }
    }
    
    @objc func startTimePressed() {
        if !timerIsActive && isTimerExcercise! && attempt < nrOfAttempts!+1 {
            playTimer = Timer.scheduledTimer(timeInterval: 20, target: self, selector: #selector(self.Play), userInfo: nil, repeats: false)
            clockTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(self.updateTime), userInfo: nil, repeats: true)
            timerValue = 20
            timerIsActive = true
            startTime.image = #imageLiteral(resourceName: "stopTime")
            timerHasBeenActive = true
            save.alpha = 0.3
            cancel.alpha = 0.3
            nextText.alpha = 0.3
            nextArrow.alpha = 0.3
            if attempt > 1 {
                prevText.alpha = 0.3
                prevArrow.alpha = 0.3
            }
        } else if timerIsActive && isTimerExcercise! && attempt < nrOfAttempts!+1 {
            timerIsActive = false
            startTime.image = #imageLiteral(resourceName: "startTime")
            playTimer!.invalidate()
            clockTimer!.invalidate()
            timerValue = 20
            timerLabel.text = String(timerValue)
            save.alpha = 1
            cancel.alpha = 1
            nextText.alpha = 1
            nextArrow.alpha = 1
            if attempt > 1 {
                prevText.alpha = 1
                prevArrow.alpha = 1
            }
        }
    }
    
    @objc func directionPressed() {
        if directionLabel.text == "höger" {
            directionLabel.text = "vänster"
        } else if directionLabel.text == "vänster" {
            directionLabel.text = "höger"
        }
    }
    
    
    
    // ---------------------------------------------------------------------------------------
    // ---------------------------------------- Methods --------------------------------------
    // ---------------------------------------------------------------------------------------
    
    // Dismiss keyboard when hitting enter after finnished writing:
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
    
    func getAverage() -> Double {
        var sum: Double = 0
        for i in 0...nrOfAttempts!-1 {
            sum += results![i]
        }
        return sum/(Double(nrOfAttempts!))
    }
    
    func getTotal() -> Double {
        var sum: Double = 0
        for i in 0...nrOfAttempts!-1 {
            sum += results![i]
        }
        return sum
    }
    
    @objc func Play() { // Ljud
        if timerIsActive {
            audioPlayer.play()
            timerIsActive = false
            startTime.image = #imageLiteral(resourceName: "startTime")
            save.alpha = 1
            cancel.alpha = 1
            nextText.alpha = 1
            nextArrow.alpha = 1
            if attempt > 1 {
                prevText.alpha = 1
                prevArrow.alpha = 1
            }
        }
    }
    
    @objc func updateTime() {
        timerValue = timerValue - 1
        if timerValue == 0 {
            clockTimer!.invalidate()
            timerValue = 20
        }
        timerLabel.text = String(timerValue)
    }
    
    
    // ---------------------------------------------------------------------------------------
    // ---------------------------------------- Prepare for segue ----------------------------
    // ---------------------------------------------------------------------------------------
    // Send data to the main menu when exiting or finished with exercise
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "showMenuFromInteger") {
            let vc_ny = (segue.destination as! ViewController)
            vc_ny.nameID = IDInput.selectedRow(inComponent: 0)
            vc_ny.activeMenuWindow = self.activeMenuWindow!
            vc_ny.host = self.host!
            vc_ny.equipmentChoice = self.equipmentChoice!
            if shouldSave {
                vc_ny.tableName = String(idArray![IDInput.selectedRow(inComponent: 0)])
                vc_ny.data = results!
                vc_ny.tableResult = String(format: "%.1f", getAverage())
                vc_ny.tableIsInteger = true
                vc_ny.tableImage = UIImage(named: String(format: "tblOvn%d", exerciseNr!))
                
                if shouldChangeEquipment![equipmentChoice!-1] {
                    vc_ny.tableEquipmentTxt = equipmentsTxt[equipmentChoice!+4-1]
                    vc_ny.tableEquipment = UIImage(named: String(format: "tblEqu%d", equipmentChoice!+4))
                } else {
                    vc_ny.tableEquipmentTxt = equipmentsTxt[equipmentChoice!-1]
                    vc_ny.tableEquipment = UIImage(named: String(format: "tblEqu%d", equipmentChoice!))
                }
                
                if isMiniGolf! {
                    vc_ny.tableEquipmentDir = directionLabel.text
                } else {
                    vc_ny.tableEquipmentDir = ""
                }
                vc_ny.addToTableBool = true
                vc_ny.tableExercise = exerciseTitleVar
                vc_ny.tableExerciseNr = exerciseNr!
            }
        }
    }
    
    
    
    // ---------------------------------------------------------------------------------------
    // ---------------------------------------- CollectionView Delegate ----------------------
    // ---------------------------------------------------------------------------------------
    
    // tell the collection view how many cells to make
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.nrOfAttempts!
    }
    
    // make a cell for each cell index path
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        // get a reference to our storyboard cell
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collectionCellNum", for: indexPath as IndexPath) as! CollectionViewCellNum
        cell.attemptNr.text = String(indexPath.row+1)
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        // handle tap events
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: CGFloat(Float(collectionView.frame.size.width)/Float(nrOfAttempts!)), height: collectionView.frame.size.height);
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    
    
    // ---------------------------------------------------------------------------------------
    // ---------------------------------------- PickerViewDelegate Methods -------------------
    // ---------------------------------------------------------------------------------------
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView == self.IDInput {
            return idArray!.count
        } else {
            return pickerArray!.count
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerView == self.IDInput {
            return String(idArray![row])
        } else {
            return String(pickerArray![row])
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.updateEquipments(setToActive: -1)
    }
    
    
    
    // ---------------------------------------------------------------------------------------
    // ---------------------------------------- Pop-Ups / Error Messages ---------------------
    // ---------------------------------------------------------------------------------------
    
    func showNotFinishedWithExercise() {
        let notFinishedErrorAlert = UIAlertController(title: "Du är inte klar med övningen", message: "Mata in ett resultat och tryck sedan på 'Nästa' tills du fyllt alla rutor.", preferredStyle: .alert)
        let OKAction = UIAlertAction(title: "OK", style: .default) { (action) in
            // ...
        }
        notFinishedErrorAlert.addAction(OKAction)
        self.present(notFinishedErrorAlert, animated: true) {
            // ...
        }
    }
    
    func showConfirmation() {
        let confirmationAlert = UIAlertController(title: "Du har valt:", message: "ID: " + String(idArray![IDInput.selectedRow(inComponent: 0)]) + "\n Är du nöjd med dina val?", preferredStyle: UIAlertControllerStyle.alert)
       
        let YESAction = UIAlertAction(title: "JA", style: .default) { (action) in
            self.shouldSave = true
            self.performSegue(withIdentifier: "showMenuFromInteger", sender: self)
        }
        let NOAction = UIAlertAction(title: "NEJ", style: .default) { (action) in
            // Gå tillbaka
        }
        confirmationAlert.addAction(NOAction)
        confirmationAlert.addAction(YESAction)
        self.present(confirmationAlert, animated: true) {
            // ...
        }
    }
    
    func showCancelConfirmation() {
        let cancelAlert = UIAlertController(title: "Är du säker på att du vill gå tillbaka till menyn?", message: "" , preferredStyle: UIAlertControllerStyle.alert)
        let YESAction = UIAlertAction(title: "JA", style: .default) { (action) in
            self.shouldSave = false
            self.performSegue(withIdentifier: "showMenuFromInteger", sender: self)
        }
        let NOAction = UIAlertAction(title: "NEJ", style: .default) { (action) in
            // Gå tillbaka
        }
        cancelAlert.addAction(NOAction)
        cancelAlert.addAction(YESAction)
        self.present(cancelAlert, animated: true)
    }
    
    
    
    
    // Standard method to have here
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
