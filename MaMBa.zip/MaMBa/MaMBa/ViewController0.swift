//
//  ViewController0.swift
//  BollApp2
//
//  Created by Fredrik Beiron on 11/02/16.
//  Copyright © 2016 Fredrik Beiron. All rights reserved.
//

import UIKit
import MessageUI

protocol TableDelegate {
    func updateArrays()
}

class ViewController0: UIViewController , UITableViewDataSource, UITableViewDelegate, TableViewCellDelegate, MFMailComposeViewControllerDelegate {
    
    // --------------------------------------------------------------------------------------
    // ----------------------------------- Variables ----------------------------------------
    // --------------------------------------------------------------------------------------
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var dataMessage: UILabel!
    @IBOutlet weak var mailButton: UIImageView!
    @IBOutlet weak var deleteButton: UIImageView!
    @IBOutlet weak var eraseAllText: UILabel!
    
    var tableItems = [MyTableType]()
    var selectedRowIndex = -1
    
    var path1: URL?
    
    var delegate: TableDelegate?

    
    var pathOK: Bool = false
    
    let file1: String = "data.csv" //this is the files we save the data to and attach when sending e-mail

    
    
    
    // --------------------------------------------------------------------------------------
    // ----------------------------------- View did load ------------------------------------
    // --------------------------------------------------------------------------------------
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let tapGestureMail = UITapGestureRecognizer(target: self, action: #selector(self.sendMail))
        self.mailButton.addGestureRecognizer(tapGestureMail)
        let tapGestureDelete = UITapGestureRecognizer(target: self, action: #selector(self.deleteAllElements))
        self.deleteButton.addGestureRecognizer(tapGestureDelete)
        
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(TableViewCell.self, forCellReuseIdentifier: "cell")
        tableView.register(TableViewCell.self, forCellReuseIdentifier: "cellNum")
        tableView.register(TableViewCell.self, forCellReuseIdentifier: "cellBool")
        
        // Register custom cell
        let nib = UINib(nibName: "nibCell", bundle: nil)
        tableView.register(nib, forCellReuseIdentifier: "cell")
        
        let nibNum = UINib(nibName: "TableViewCellNum", bundle: nil)
        tableView.register(nibNum, forCellReuseIdentifier: "cellNum")
        
        let nibBool = UINib(nibName: "TableViewCellBool", bundle: nil)
        tableView.register(nibBool, forCellReuseIdentifier: "cellBool")
        
        //self.tableView.tableFooterView = UIView(frame: CGRectZero)  // Remove "empty cells" after last cell
        
        // Load data
        let defaults = UserDefaults.standard
        if let savedData = defaults.object(forKey: "tableItems") as? Data {
            tableItems = NSKeyedUnarchiver.unarchiveObject(with: savedData) as! [MyTableType]
        }
        if tableItems.count == 0 {
            dataMessage.text = "Du har inga sparade resultat."
        } else {
            dataMessage.text = ""
        }
        
        if let dir = NSSearchPathForDirectoriesInDomains(FileManager.SearchPathDirectory.documentDirectory, FileManager.SearchPathDomainMask.allDomainsMask, true).first {
            path1 = URL(fileURLWithPath: dir).appendingPathComponent(file1)
            pathOK = true
        }
    }
    
    
    
    // --------------------------------------------------------------------------------------
    // ----------------------------------- Methods ------------------------------------------
    // --------------------------------------------------------------------------------------
    
    /*func addTableItem(_ tblName: String, tblResult: String, tblImage: UIImage, /*tblEquipment: UIImage,*/ data: [Double], exercise: String, isInteger: Bool) {
        tableItems.append(TableItem(cellName: tblName, cellResult: tblResult, cellImage: tblImage, /*cellEquipment: tblEquipment,*/ data: data, cellExercise: exercise, isInteger: isInteger))
        self.save()
        dataMessage.text = ""
    }*/
    
    func addTableItemNum(_ tblName: String, tblResult: String, tblImage: UIImage, tblEquipment: UIImage, tblEquipmentTxt: String, tblEquipmentDir: String, data: [Double], exercise: String, exerciseNr: Int, isInteger: Bool) {
        tableItems.append(TableItemNumeric(cellName: tblName, cellResult: tblResult, cellImage: tblImage, cellEquipment: tblEquipment, cellEquipmentTxt: tblEquipmentTxt, cellEquipmentDir: tblEquipmentDir, data: data, cellExercise: exercise, cellExerciseNr: exerciseNr, isInteger: isInteger))
        self.save()
        dataMessage.text = ""
    }
    
    func addTableItemBool(_ tblName: String, tblResult: String, tblImage: UIImage, tblEquipment: UIImage, tblEquipmentTxt: String, data: [Bool], exercise: String, exerciseNr: Int, isInteger: Bool) {
        tableItems.append(TableItemBoolean(cellName: tblName, cellResult: tblResult, cellImage: tblImage, cellEquipment: tblEquipment, cellEquipmentTxt: tblEquipmentTxt, data: data, cellExercise: exercise, cellExerciseNr: exerciseNr, isInteger: isInteger))
        self.save()
        dataMessage.text = ""
    }
    
    func clearData(_ path: URL) {
        let emptyText = ""
        do {
            try emptyText.write(to: path, atomically: false, encoding: String.Encoding.utf8)
        }
        catch {print("Fel vid rensning av datafiler")}
    }
    
    func save() {
        let savedData = NSKeyedArchiver.archivedData(withRootObject: tableItems)
        let defaults = UserDefaults.standard
        defaults.set(savedData, forKey: "tableItems")
    }
    
    // ----------------------------------- Create files to send through mail -----------------
    func setData(_ path: URL) {
 
        var dataString = ""
        if tableItems.count == 0 {
            return
        }
        for i in 0...tableItems.count-1 {
            
            if (i == 0) {
                dataString = dataString + "ID" + ", " + "Övning" + ", " + "Utrustning" + ", " + "Höger/Vänster" + ", " + "Försök_1" + ", " + "Försök_2" + ", " + "Försök_3" + ", " + "Försök_4" + ", " + "Försök_5" + ", " + "Försök_6" + ", " + "Försök_7" + ", " + "Försök_8" + ", " + "Försök_9" + ", " + "Försök_10" + "\n"
            }
            if let item = tableItems[i] as? TableItemNumeric { // double value as result
                let s1:String = item.name + ", " + item.exercise + ", " + item.equipment_txt + ", " + item.equipment_dir
                dataString = dataString + s1
                for j in 0...item.data.count-1 {
                    let s2:String = ", " + String(item.data[j])
                    dataString = dataString + s2
                }
                if item.data.count < 9 {
                    for _ in item.data.count...9 {
                        dataString = dataString + ", "
                    }
                }
                dataString = dataString + "\n"
            } else if let item = tableItems[i] as? TableItemBoolean { // Boolean value as result
                let s1:String = item.name + ", " + item.exercise + ", " + item.equipment_txt + ", "
                dataString = dataString + s1
                for j in 0...item.data.count-1 {
                    let s2:String = ", "  + String(item.data[j])
                    dataString = dataString + s2
                }
                if item.data.count < 9 {
                    for _ in item.data.count...9 {
                        dataString = dataString + ", "
                    }
                }
                dataString = dataString + "\n"
            }
            
        }
        do {
            try dataString.write(to: path, atomically: false, encoding: String.Encoding.utf8)
        }
        catch{print("Error while setData()")}
 
    }
    
    
    
    // --------------------------------------------------------------------------------------
    // ----------------------------------- Button pressed methods ---------------------------
    // --------------------------------------------------------------------------------------
    
    // ----------------------------------- delete was pressed -------------------------------
    @objc func deleteAllElements(_ sender: AnyObject) {       // clear the table
        if self.tableItems.count == 0 {
            showNoDataToDeleteErrorAlert()
            return
        }
        let deleteAllNotification = UIAlertController(title: "Radera alla sparade resultat?", message: "Är du säker på att du vill radera alla sparade resultat?", preferredStyle: .alert)
        let YESAction = UIAlertAction(title: "JA", style: .default) { (action) in
            let lastIndex = self.tableItems.count-1
            for i in 0...lastIndex {
                self.tableItems.remove(at: lastIndex-i)
                self.tableView.beginUpdates()
                let indexPathForRow = IndexPath(row: lastIndex-i, section: 0)
                self.tableView.deleteRows(at: [indexPathForRow], with: .fade)
                self.tableView.endUpdates()
                self.save()
            }
            self.dataMessage.text = "Du har inga sparade resultat"
            self.delegate?.updateArrays()
        }
        let NOAction = UIAlertAction(title: "NEJ", style: .default) { (action) in
            // ...
        }
        deleteAllNotification.addAction(NOAction)
        deleteAllNotification.addAction(YESAction)
        self.present(deleteAllNotification, animated: true) {
            // ...
        }
    }
    
    // ----------------------------------- send mail was pressed ----------------------------
    @objc func sendMail(_ sender: AnyObject) {
        if (tableItems.count > 0) {
            let mailComposeViewController = configuredMailComposeViewController()
            if MFMailComposeViewController.canSendMail() {
                self.present(mailComposeViewController, animated: true, completion: nil)
            } else {
                self.showSendMailErrorAlert()
            }
        } else {
            showNoDataToSendErrorAlert()
        }
    }
    
    
    
    // --------------------------------------------------------------------------------------
    // ----------------------------------- MFMailComposer -----------------------------------
    // --------------------------------------------------------------------------------------
    
    func configuredMailComposeViewController() -> MFMailComposeViewController {
        let mailComposerVC = MFMailComposeViewController()
        mailComposerVC.mailComposeDelegate = self
        
        //mailComposerVC.setToRecipients([""])
        mailComposerVC.setSubject("Skickar resultat från appen MaMBa")
        /*mailComposerVC.setMessageBody("<p>The data is structured as follows:</p> <ul><li>data1 - Time exercises (simple)</li><li>data2 - Time exercises</li><li>data3 - Distance exercises (simple)</li><li>data4 - Distance exercises</li></ul>", isHTML: true)*/
        
        if (pathOK) {
            self.clearData(path1!)
            self.setData(path1!)

            if let fileData = try? Data(contentsOf: path1!) {
                //print("File data loaded.")
                mailComposerVC.addAttachmentData(fileData, mimeType: "text/tsv", fileName: "data.csv")
            }
            
        }
        return mailComposerVC
    }
    
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true, completion: nil)
    }
    
    
    
    // --------------------------------------------------------------------------------------
    // ----------------------------------- TableView - Delegate -----------------------------
    // --------------------------------------------------------------------------------------
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableItems.count
    }
    
    func tableView(_ tableView: UITableView,
                   cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let item = tableItems[indexPath.row] as? TableItem {
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TableViewCell
            cell.name.text = item.name
            cell.result.text = item.result
            cell.imageExercise.image = item.image
            cell.backgroundColor = UIColor.clear
            cell.delegate = self
            cell.tableItem = item
            return cell
        } else {
            if let item = tableItems[indexPath.row] as? TableItemNumeric {  // numeric exercise
                let cell = tableView.dequeueReusableCell(withIdentifier: "cellNum", for: indexPath) as! TableViewCellNum
                cell.name.text = "ID: \(item.name)"
                cell.imageExercise.image = item.image
                cell.imageEquipment.image = item.equipment
                cell.result.text = item.result
                if item.data.count == 1 {
                    cell.resultText.text = "Resultat:"
                } else {
                    cell.resultText.text = "Genomsnitt:"
                }
                cell.backgroundColor = UIColor.clear
                cell.delegate = self
                cell.tableItem = item
                return cell
            } else {
                let item = tableItems[indexPath.row] as! TableItemBoolean   // boolean exercise
                let cell = tableView.dequeueReusableCell(withIdentifier: "cellBool", for: indexPath) as! TableViewCellBool
                cell.name.text = "ID: \(item.name)"
                cell.imageExercise.image = item.image
                cell.imageEquipment.image = item.equipment
                cell.result.text = item.result
                cell.backgroundColor = UIColor.clear
                cell.delegate = self
                cell.tableItem = item
                return cell
            }
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.selectedRowIndex = indexPath.row
        // Remove all text from other cells
        for i in 0...tableItems.count-1 {
            if let cell = tableView.cellForRow(at: IndexPath(row: i, section: 0)) as? TableViewCellNum {
                let cellArray: [UILabel] = [cell.label1, cell.label2, cell.label3, cell.label4, cell.label5, cell.label6, cell.label7, cell.label8, cell.label9, cell.label10, cell.label11, cell.label12, cell.label13, cell.label14, cell.label15, cell.label16, cell.label17, cell.label18, cell.label19, cell.label20]
                cell.ovnLabel.text = ""
                for j in 0...19 {
                    cellArray[j].text = ""
                }
            }
            if let cell = tableView.cellForRow(at: IndexPath(row: i, section: 0)) as? TableViewCellBool {
                let cellArray: [UILabel] = [cell.label1, cell.label2, cell.label3, cell.label4, cell.label5, cell.label6, cell.label7, cell.label8, cell.label9, cell.label10, cell.label11, cell.label12, cell.label13, cell.label14, cell.label15, cell.label16, cell.label17, cell.label18, cell.label19, cell.label20]
                let imgArray: [UIImageView] = [cell.img1, cell.img2, cell.img3, cell.img4, cell.img5, cell.img6, cell.img7, cell.img8, cell.img9, cell.img10, cell.img11, cell.img12, cell.img13, cell.img14, cell.img15, cell.img16, cell.img17, cell.img18, cell.img19, cell.img20]
                cell.ovnLabel.text = ""
                for j in 0...19 {
                    cellArray[j].text = ""
                    imgArray[j].image = UIImage(named: "")
                }
            }
        }
        // Add text to the selected cell
        if let cell = tableView.cellForRow(at: indexPath) as? TableViewCellNum {
            if let item = tableItems[indexPath.row] as? TableItemNumeric {
                cell.ovnLabel.text = item.exercise
                let cellArray: [UILabel] = [cell.label1, cell.label2, cell.label3, cell.label4, cell.label5, cell.label6, cell.label7, cell.label8, cell.label9, cell.label10, cell.label11, cell.label12, cell.label13, cell.label14, cell.label15, cell.label16, cell.label17, cell.label18, cell.label19, cell.label20]
                let rows = item.data.count
                for i in 0...rows-1 {
                    if item.isInteger {
                        cellArray[i].text = "Rep \(i+1):   \(Int(item.data[i]))"
                    } else {
                        cellArray[i].text = "Rep \(i+1):   \(round(item.data[i]*100)/100)"
                    }
                }
            }
        }
        if let cell = tableView.cellForRow(at: indexPath) as? TableViewCellBool {
            if let item = tableItems[indexPath.row] as? TableItemBoolean {
                cell.ovnLabel.text = item.exercise
                let cellArray: [UILabel] = [cell.label1, cell.label2, cell.label3, cell.label4, cell.label5, cell.label6, cell.label7, cell.label8, cell.label9, cell.label10, cell.label11, cell.label12, cell.label13, cell.label14, cell.label15, cell.label16, cell.label17, cell.label18, cell.label19, cell.label20]
                let imgArray: [UIImageView] = [cell.img1, cell.img2, cell.img3, cell.img4, cell.img5, cell.img6, cell.img7, cell.img8, cell.img9, cell.img10, cell.img11, cell.img12, cell.img13, cell.img14, cell.img15, cell.img16, cell.img17, cell.img18, cell.img19, cell.img20]
                let rows = item.data.count
                for i in 0...rows-1 {
                    let bool = item.data[i]
                    cellArray[i].text = "Rep \(i+1):   "
                    if bool {
                        imgArray[i].image = #imageLiteral(resourceName: "completed")
                    } else {
                        imgArray[i].image = #imageLiteral(resourceName: "delete")
                    }
                }
            }
        }
        
        // update all the cells
        self.tableView.beginUpdates()
        self.tableView.endUpdates()
    }
    
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        self.selectedRowIndex = -1
        // Remove all text from cells
        for i in 0...tableItems.count-1 {
            if let cell = tableView.cellForRow(at: IndexPath(row: i, section: 0)) as? TableViewCellNum {
                let cellArray: [UILabel] = [cell.label1, cell.label2, cell.label3, cell.label4, cell.label5, cell.label6, cell.label7, cell.label8, cell.label9, cell.label10, cell.label11, cell.label12, cell.label13, cell.label14, cell.label15, cell.label16, cell.label17, cell.label18, cell.label19, cell.label20]
                cell.ovnLabel.text = ""
                for j in 0...19 {
                    cellArray[j].text = ""
                }
            }
            if let cell = tableView.cellForRow(at: IndexPath(row: i, section: 0)) as? TableViewCellBool {
                let cellArray: [UILabel] = [cell.label1, cell.label2, cell.label3, cell.label4, cell.label5, cell.label6, cell.label7, cell.label8, cell.label9, cell.label10, cell.label11, cell.label12, cell.label13, cell.label14, cell.label15, cell.label16, cell.label17, cell.label18, cell.label19, cell.label20]
                let imgArray: [UIImageView] = [cell.img1, cell.img2, cell.img3, cell.img4, cell.img5, cell.img6, cell.img7, cell.img8, cell.img9, cell.img10, cell.img11, cell.img12, cell.img13, cell.img14, cell.img15, cell.img16, cell.img17, cell.img18, cell.img19, cell.img20]
                cell.ovnLabel.text = ""
                for j in 0...19 {
                    cellArray[j].text = ""
                    imgArray[j].image = UIImage(named: "")
                }
            }
        }
        // update all the cells
        self.tableView.beginUpdates()
        self.tableView.endUpdates()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt
        indexPath: IndexPath) -> CGFloat {
        let horizontalClass = self.traitCollection.horizontalSizeClass
        
        switch (horizontalClass) {
        case .regular :
            if self.selectedRowIndex == indexPath.row {
                return 300
            }
            return 125
        case .compact :
            if self.selectedRowIndex == indexPath.row {
                return 200
            }
            return 75
        default :
            if self.selectedRowIndex == indexPath.row {
                return 200
            }
            return 75
        }
    }
    
    func tableItemDeleted(_ tableItem: MyTableType) {
        let index = (tableItems as NSArray).index(of: tableItem)
        if index == NSNotFound { return }
        
        // could removeAtIndex in the loop but keep it here for when indexOfObject works
        tableItems.remove(at: index)
        
        // use the UITableView to animate the removal of this row
        tableView.beginUpdates()
        let indexPathForRow = IndexPath(row: index, section: 0)
        tableView.deleteRows(at: [indexPathForRow], with: .fade)
        tableView.endUpdates()
        self.save()
        if tableItems.count == 0 {
            dataMessage.text = "Du har inga sparade resultat"
        }
        self.delegate?.updateArrays()
    }
    
    
    
    // --------------------------------------------------------------------------------------
    // ----------------------------------- POP-UP messages ----------------------------------
    // --------------------------------------------------------------------------------------
    
    func showNoDataToSendErrorAlert() {
        let NoDataToSendErrorAlert = UIAlertController(title: "Inga resultat att skicka", message: nil, preferredStyle: .alert)
        let OKAction = UIAlertAction(title: "OK", style: .default) { (action) in
        }
        NoDataToSendErrorAlert.addAction(OKAction)
        self.present(NoDataToSendErrorAlert, animated: true) {
            // ...
        }
    }
    
    func showNoDataToDeleteErrorAlert() {
        let NoDataToDeleteErrorAlert = UIAlertController(title: "Inga resultat att radera", message: nil, preferredStyle: .alert)
        let OKAction = UIAlertAction(title: "OK", style: .default) { (action) in
        }
        NoDataToDeleteErrorAlert.addAction(OKAction)
        self.present(NoDataToDeleteErrorAlert, animated: true) {
            // ...
        }
    }
    
    func showSendMailErrorAlert() {
        let sendMailErrorAlert = UIAlertController(title: "Kunde inte skicka mail", message: "Din enhet kunde inte skicka mail.  Var god kontrollera inställningar för mail och försök igen.", preferredStyle: .alert)
        let OKAction = UIAlertAction(title: "OK", style: .default) { (action) in
            // ...
        }
        sendMailErrorAlert.addAction(OKAction)
        self.present(sendMailErrorAlert, animated: true) {
            // ...
        }
    }
    
    func showShouldTableItemBeDeleted(_ tableItem: MyTableType) {
        let shouldDeleteErrorAlert = UIAlertController(title: "Vill du radera?", message: nil, preferredStyle: .alert)
        let YESAction = UIAlertAction(title: "JA", style: .default) { (action) in
            self.tableItemDeleted(tableItem)
        }
        let NOAction = UIAlertAction(title: "NEJ", style: .default) { (action) in
            // ...
        }

        shouldDeleteErrorAlert.addAction(NOAction)
        shouldDeleteErrorAlert.addAction(YESAction)
        self.present(shouldDeleteErrorAlert, animated: true) {
            // ...
        }
    }
    
}
