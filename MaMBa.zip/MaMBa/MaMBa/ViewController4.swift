//
//  ViewController4ViewController.swift
//  MaMBa
//
//  Created by Fredrik Beiron on 2017-06-09.
//  Copyright © 2017 Fredrik Beiron. All rights reserved.
//

import UIKit

class ViewController4: UIViewController {

    @IBOutlet weak var ovn13: UIImageView!
    @IBOutlet weak var ovn14: UIImageView!
    @IBOutlet weak var ovn15: UIImageView!
    @IBOutlet weak var ovn16: UIImageView!
    @IBOutlet weak var ovn17: UIImageView!
    @IBOutlet weak var ovn18: UIImageView!
    
    @IBOutlet weak var ovnNr13: UILabel!
    @IBOutlet weak var ovnNr14: UILabel!
    @IBOutlet weak var ovnNr15: UILabel!
    @IBOutlet weak var ovnNr16: UILabel!
    @IBOutlet weak var ovnNr17: UILabel!
    @IBOutlet weak var ovnNr18: UILabel!
    
    @IBOutlet weak var ovnLabel13: UILabel!
    @IBOutlet weak var ovnLabel14: UILabel!
    @IBOutlet weak var ovnLabel15: UILabel!
    @IBOutlet weak var ovnLabel16: UILabel!
    @IBOutlet weak var ovnLabel17: UILabel!
    @IBOutlet weak var ovnLabel18: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
