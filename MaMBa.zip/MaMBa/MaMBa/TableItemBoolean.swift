//
//  TableItemBoolean.swift
//  MaMBa
//
//  Created by Fredrik Beiron on 2017-04-17.
//  Copyright © 2017 Fredrik Beiron. All rights reserved.
//

import UIKit

class TableItemBoolean: NSObject, NSCoding, MyTableType {
    var name: String
    var result: String
    var image: UIImage
    var equipment: UIImage
    var equipment_txt: String
    var data: [Bool]
    var exercise: String
    var exerciseNr: Int
    var isInteger: Bool
    var completed: Bool     // A Boolean value that determines the completed state of this item.
    
    required init(coder aDecoder: NSCoder) {
        name = aDecoder.decodeObject(forKey: "name") as! String
        result = aDecoder.decodeObject(forKey: "result") as! String
        image = aDecoder.decodeObject(forKey: "image") as! UIImage
        equipment = aDecoder.decodeObject(forKey: "equipment") as! UIImage
        equipment_txt = aDecoder.decodeObject(forKey: "equipment_txt") as! String
        data = aDecoder.decodeObject(forKey: "dataBool") as! [Bool]
        completed = aDecoder.decodeBool(forKey: "completed")
        exercise = aDecoder.decodeObject(forKey: "exercise") as! String
        exerciseNr = aDecoder.decodeInteger(forKey: "exerciseNr")
        isInteger = aDecoder.decodeBool(forKey: "isInteger")

    }
    
    func encode(with aCoder: NSCoder) {
        aCoder.encode(name, forKey: "name")
        aCoder.encode(result, forKey: "result")
        aCoder.encode(image, forKey: "image")
        aCoder.encode(equipment, forKey: "equipment")
        aCoder.encode(equipment_txt, forKey: "equipment_txt")
        aCoder.encode(data, forKey: "dataBool")
        aCoder.encode(completed, forKey: "completed")
        aCoder.encode(exercise, forKey: "exercise")
        aCoder.encode(exerciseNr, forKey: "exerciseNr")
        aCoder.encode(isInteger, forKey: "isInteger")
    }
    
    // Returns a tableItem initialized with the given text and default completed value.
    init(cellName: String, cellResult: String, cellImage: UIImage, cellEquipment: UIImage, cellEquipmentTxt: String, data: [Bool], cellExercise: String, cellExerciseNr: Int, isInteger: Bool) {
        self.name = cellName
        self.result = cellResult
        self.completed = false
        self.image = cellImage
        self.equipment = cellEquipment
        self.equipment_txt = cellEquipmentTxt
        self.data = data
        self.exercise = cellExercise
        self.exerciseNr = cellExerciseNr
        self.isInteger = isInteger
    }
}
