//
//  TableItem.swift
//  BollApp2
//
//  Created by Fredrik Beiron on 12/02/16.
//  Copyright © 2016 Fredrik Beiron. All rights reserved.
//

import UIKit

protocol MyTableType {
    
}

class TableItem: NSObject, NSCoding, MyTableType {
    var name: String
    var image: UIImage
    var result: String
    //var equipment: UIImage
    var data: [Double]
    var exercise: String
    var isInteger: Bool
    var completed: Bool     // A Boolean value that determines the completed state of this item.
    
    required init(coder aDecoder: NSCoder) {
        name = aDecoder.decodeObject(forKey: "name") as? String ?? ""
        image = aDecoder.decodeObject(forKey: "image") as! UIImage
        result = aDecoder.decodeObject(forKey: "result") as? String ?? ""
        //equipment = aDecoder.decodeObject(forKey: "equipment") as! UIImage
        data = aDecoder.decodeObject(forKey: "data") as! [Double]
        completed = aDecoder.decodeBool(forKey: "completed")
        exercise = aDecoder.decodeObject(forKey: "exercise") as? String ?? ""
        isInteger = aDecoder.decodeBool(forKey: "isInteger")
    }
    
    func encode(with aCoder: NSCoder) {
        aCoder.encode(name, forKey: "name")
        aCoder.encode(image, forKey: "image")
        aCoder.encode(result, forKey: "result")
        //aCoder.encode(equipment, forKey: "equipment")
        aCoder.encode(data, forKey: "data")
        aCoder.encode(completed, forKey: "completed")
        aCoder.encode(exercise, forKey: "exercise")
        aCoder.encode(isInteger, forKey: "isInteger")
    }
    
    // Returns a tableItem initialized with the given text and default completed value.
    init(cellName: String, cellResult: String, cellImage: UIImage, cellEquipment: UIImage, data: [Double], cellExercise: String, isInteger: Bool) {
        self.name = cellName
        self.completed = false
        self.image = cellImage
        //self.equipment = cellEquipment
        self.result = cellResult
        self.data = data
        self.exercise = cellExercise
        self.isInteger = isInteger
    }
}
