//
//  ViewController3.swift
//  BollApp2
//
//  Created by Fredrik Beiron on 25/02/16.
//  Copyright © 2016 Fredrik Beiron. All rights reserved.
//

import UIKit

class ViewController3: UIViewController {

    @IBOutlet weak var ovn8: UIImageView!
    @IBOutlet weak var ovn7: UIImageView!
    @IBOutlet weak var ovn9: UIImageView!
    @IBOutlet weak var ovn10: UIImageView!
    @IBOutlet weak var ovn11: UIImageView!
    @IBOutlet weak var ovn12: UIImageView!
    
    @IBOutlet weak var ovnNr7: UILabel!
    @IBOutlet weak var ovnNr8: UILabel!
    @IBOutlet weak var ovnNr9: UILabel!
    @IBOutlet weak var ovnNr10: UILabel!
    @IBOutlet weak var ovnNr11: UILabel!
    @IBOutlet weak var ovnNr12: UILabel!
    
    @IBOutlet weak var ovnLabel7: UILabel!
    @IBOutlet weak var ovnLabel8: UILabel!
    @IBOutlet weak var ovnLabel9: UILabel!
    @IBOutlet weak var ovnLabel10: UILabel!
    @IBOutlet weak var ovnLabel11: UILabel!
    @IBOutlet weak var ovnLabel12: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
