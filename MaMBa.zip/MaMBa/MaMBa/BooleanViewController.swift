//
//  BooleanViewController.swift
//  GoFlow
//
//  Created by Fredrik Beiron on 2017-04-07.
//  Copyright © 2017 Fredrik Beiron. All rights reserved.
//

import UIKit
//import AudioToolbox // vibrate

class BooleanViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate, UITextFieldDelegate, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    // --------------------------------------------------------------------------------------
    // ----------------------------------- Variables ----------------------------------------
    // --------------------------------------------------------------------------------------
    
    @IBOutlet weak var exerciseTitle: UILabel!
    @IBOutlet weak var cancel: UIImageView!
    @IBOutlet weak var save: UIImageView!
    @IBOutlet weak var handImage: UIImageView!
    @IBOutlet weak var racketImage: UIImageView!
    @IBOutlet weak var clubImage: UIImageView!
    @IBOutlet weak var footImage: UIImageView!
    @IBOutlet weak var succeeded: UIImageView!
    @IBOutlet weak var failed: UIImageView!
    @IBOutlet weak var resultText: UILabel!
    @IBOutlet weak var IDInput: UIPickerView!
    @IBOutlet weak var nextButton: UIButton!
    @IBOutlet weak var prevButton: UIButton!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var nextArrow: UIImageView!
    @IBOutlet weak var prevArrow: UIImageView!
    @IBOutlet weak var nextText: UILabel!
    @IBOutlet weak var prevText: UILabel!
    
    
    var shouldSave: Bool = false
    var attempt: Int = 1
    
    var exerciseTitleVar: String?
    
    // Variables for equipment
    var equipmentChoice: Int?           // hand = 1, foot = 2, racket = 3, club = 4
    var activeEquipments: [[Int]]?        // [1, 1, 0, 0] => only hand and foot can be chosen in this exercise
    var shouldChangeEquipment: [Bool]?
    
    var nameID: Int?
    var exerciseNr: Int?
    var nrOfAttempts: Int?
    var idArray: [Int]?
    
    var isMiniGolf: Bool?
    
    var host: String?
    var activeMenuWindow: Int?
    
    var result: Bool = false
    var results: [Bool]?
    
    let equipmentsTxt = ["hand", "fot", "rack", "klubba", "armbåge", "lår", "slagträ", "huvud"]
    
    // --------------------------------------------------------------------------------------
    // ----------------------------------- View did load ------------------------------------
    // --------------------------------------------------------------------------------------

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.layoutIfNeeded()
        
        self.IDInput.dataSource = self;
        self.IDInput.delegate = self;
        
        self.collectionView.dataSource = self;
        self.collectionView.delegate = self;
        
        collectionView.register(UINib(nibName: "CollectionViewCellBool", bundle: nil), forCellWithReuseIdentifier: "collectionCellBool")
        
        let tapGestureCancel = UITapGestureRecognizer(target: self, action: #selector(self.cancelPressed))
        self.cancel.addGestureRecognizer(tapGestureCancel)
        
        let tapGestureSave = UITapGestureRecognizer(target: self, action: #selector(self.savePressed))
        self.save.addGestureRecognizer(tapGestureSave)
        
        let tapGestureHand = UITapGestureRecognizer(target: self, action: #selector(self.handPressed))
        self.handImage.addGestureRecognizer(tapGestureHand)
        
        let tapGestureFoot = UITapGestureRecognizer(target: self, action: #selector(self.footPressed))
        self.footImage.addGestureRecognizer(tapGestureFoot)
        
        let tapGestureRacket = UITapGestureRecognizer(target: self, action: #selector(self.racketPressed))
        self.racketImage.addGestureRecognizer(tapGestureRacket)
        
        let tapGestureClub = UITapGestureRecognizer(target: self, action: #selector(self.clubPressed))
        self.clubImage.addGestureRecognizer(tapGestureClub)
        
        let tapGestureSucceed = UITapGestureRecognizer(target: self, action: #selector(self.succeedPressed))
        self.succeeded.addGestureRecognizer(tapGestureSucceed)
        
        let tapGestureFail = UITapGestureRecognizer(target: self, action: #selector(self.failPressed))
        self.failed.addGestureRecognizer(tapGestureFail)
        
        let tapGestureNext = UITapGestureRecognizer(target: self, action: #selector(self.nextPressed))
        self.nextButton.addGestureRecognizer(tapGestureNext)
        
        let tapGesturePrev = UITapGestureRecognizer(target: self, action: #selector(self.prevPressed))
        self.prevButton.addGestureRecognizer(tapGesturePrev)
        
        exerciseTitle.text = exerciseTitleVar
        IDInput.selectRow(nameID!, inComponent: 0, animated: true)
        
        results = Array(repeatElement(false, count: nrOfAttempts!))
        
        self.updateEquipments(setToActive: -1)
    }
    
    
    
    func updateEquipments(setToActive: Int) {
        let equipmentImageViews: [UIImageView] = [handImage, footImage, racketImage, clubImage]
        let equipmentImagesON: [UIImage] = [#imageLiteral(resourceName: "handON"),#imageLiteral(resourceName: "footON"),#imageLiteral(resourceName: "racketON"),#imageLiteral(resourceName: "clubON"),#imageLiteral(resourceName: "elbowON"),#imageLiteral(resourceName: "legON"),#imageLiteral(resourceName: "batON"),#imageLiteral(resourceName: "headON")]
        let equipmentImages: [UIImage] = [#imageLiteral(resourceName: "hand"),#imageLiteral(resourceName: "foot"),#imageLiteral(resourceName: "racket"),#imageLiteral(resourceName: "club"),#imageLiteral(resourceName: "elbow"),#imageLiteral(resourceName: "leg"),#imageLiteral(resourceName: "bat"),#imageLiteral(resourceName: "head")]
        let activeID = idArray![IDInput.selectedRow(inComponent: 0)]-1
        var onIsUsed = false
        for i in 0...equipmentImageViews.count-1 {
            if activeEquipments![activeID][i] == 0 {
                equipmentImageViews[i].alpha = 0.2
                if shouldChangeEquipment![i] {
                    equipmentImageViews[i].image = equipmentImages[i+4]
                } else {
                    equipmentImageViews[i].image = equipmentImages[i]
                }
            } else {
                equipmentImageViews[i].alpha = 1.0
                if shouldChangeEquipment![i] {
                    if (onIsUsed || (i < setToActive)) {
                        equipmentImageViews[i].image = equipmentImages[i+4]
                    } else if setToActive == i || setToActive < 0 {
                        equipmentImageViews[i].image = equipmentImagesON[i+4]
                        self.equipmentChoice! = i+1
                        onIsUsed = true
                    }
                } else {
                    if (onIsUsed || (i < setToActive)) {
                        equipmentImageViews[i].image = equipmentImages[i]
                    } else if setToActive == i || setToActive < 0 {
                        equipmentImageViews[i].image = equipmentImagesON[i]
                        self.equipmentChoice! = i+1
                        onIsUsed = true
                    }
                }
            }
        }
    }
    
    
    // ---------------------------------------------------------------------------------------
    // ---------------------------------------- Button pressed methods -----------------------
    // ---------------------------------------------------------------------------------------
    
    @objc func cancelPressed() {
        self.showCancelConfirmation()
        //self.performSegue(withIdentifier: "showMenuFromBoolean", sender: self)
    }
    
    @objc func savePressed() {
        if (attempt > nrOfAttempts!) {
            self.showConfirmation()
        } else {
            self.showNotFinishedWithExercise()
        }
    }
    
    @objc func handPressed() {
        let activeID = idArray![IDInput.selectedRow(inComponent: 0)]-1
        if attempt <= nrOfAttempts! && activeEquipments![activeID][0] == 1 {
            self.updateEquipments(setToActive: 0)
            equipmentChoice = 1
        }
    }
    
    @objc func footPressed() {
        let activeID = idArray![IDInput.selectedRow(inComponent: 0)]-1
        if attempt <= nrOfAttempts! && activeEquipments![activeID][1] == 1 {
            self.updateEquipments(setToActive: 1)
            equipmentChoice = 2
        }
    }
    
    @objc func racketPressed() {
        let activeID = idArray![IDInput.selectedRow(inComponent: 0)]-1
        if attempt <= nrOfAttempts! && activeEquipments![activeID][2] == 1 {
            self.updateEquipments(setToActive: 2)
            equipmentChoice = 3
        }
    }
    
    @objc func clubPressed() {
        let activeID = idArray![IDInput.selectedRow(inComponent: 0)]-1
        if attempt <= nrOfAttempts! && activeEquipments![activeID][3] == 1 {
            self.updateEquipments(setToActive: 3)
            equipmentChoice = 4
        }
    }
    
    @objc func succeedPressed() {
        if attempt <= nrOfAttempts! && ( result == false || resultText.text == "" ) {
            //AudioServicesPlayAlertSound(SystemSoundID(kSystemSoundID_Vibrate))
            resultText.text = "LYCKADES"
            resultText.textColor = #colorLiteral(red: 0, green: 0.9768045545, blue: 0, alpha: 1)
            result = true
        }
    }
    
    @objc func failPressed() {
        if attempt <= nrOfAttempts! && ( result == true || resultText.text == "" ) {
            //AudioServicesPlayAlertSound(SystemSoundID(kSystemSoundID_Vibrate))
            resultText.text = "MISSLYCKADES"
            resultText.textColor = #colorLiteral(red: 1, green: 0.1491314173, blue: 0, alpha: 1)
            result = false
        }
    }
    
    @objc func nextPressed() {
        if (attempt <= nrOfAttempts! && resultText.text != "") {
            let cell = (collectionView!.cellForItem(at: IndexPath(row: attempt-1, section: 0)) as! CollectionViewCellBool)
            if resultText.text == "MISSLYCKADES" {
                cell.result.image = #imageLiteral(resourceName: "delete")
            } else {
                cell.result.image = #imageLiteral(resourceName: "completed")
            }
            results![attempt-1] = result
            resultText.text = ""
            if attempt == nrOfAttempts! {
                nextText.text = ""
                nextArrow.alpha = 0.0
                succeeded.alpha = 0.3
                failed.alpha = 0.3
            }
            attempt = attempt + 1
        }
    }
    
    @objc func prevPressed() {
        if attempt > 1 {
            let cell = (collectionView!.cellForItem(at: IndexPath(row: attempt-2, section: 0)) as! CollectionViewCellBool)
            cell.result.image = nil
            resultText.text = ""
            results![attempt-2] = false
            if attempt == nrOfAttempts!+1 {
                nextText.text = "Nästa"
                nextArrow.alpha = 1.0
                succeeded.alpha = 1.0
                failed.alpha = 1.0
            }
            attempt = attempt - 1
        }
    }
    
    
    
    // ---------------------------------------------------------------------------------------
    // ---------------------------------------- Methods --------------------------------------
    // ---------------------------------------------------------------------------------------
    
    // Dismiss keyboard when hitting enter after finnished writing:
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
    
    func getNumberOfSucceded() -> Int {
        var sum: Int = 0
        for i in 0...nrOfAttempts!-1 {
            if results![i] {
                sum += 1
            }
        }
        return sum
    }
    
    
    
    // ---------------------------------------------------------------------------------------
    // ---------------------------------------- Prepare for segue ----------------------------
    // ---------------------------------------------------------------------------------------
    // Send data to the main menu when exiting or finished with exercise
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "showMenuFromBoolean") {
            let vc_ny = (segue.destination as! ViewController)
            vc_ny.nameID = IDInput.selectedRow(inComponent: 0)
            vc_ny.host = self.host!
            vc_ny.activeMenuWindow = self.activeMenuWindow!
            vc_ny.equipmentChoice = self.equipmentChoice!
            if shouldSave {
                vc_ny.tableName = String(idArray![IDInput.selectedRow(inComponent: 0)])
                vc_ny.data = self.results
                vc_ny.tableResult = "\(getNumberOfSucceded()) av \(nrOfAttempts!)"
                vc_ny.tableImage = UIImage(named: String(format: "tblOvn%d", exerciseNr!))
                
                if shouldChangeEquipment![equipmentChoice!] {
                    vc_ny.tableEquipmentTxt = equipmentsTxt[equipmentChoice!+4-1]
                    vc_ny.tableEquipment = UIImage(named: String(format: "tblEqu%d", equipmentChoice!+4))
                } else {
                    vc_ny.tableEquipmentTxt = equipmentsTxt[equipmentChoice!-1]
                    vc_ny.tableEquipment = UIImage(named: String(format: "tblEqu%d", equipmentChoice!))
                }
                
                vc_ny.addToTableBool = true
                vc_ny.tableExercise = exerciseTitleVar
                vc_ny.tableExerciseNr = exerciseNr!
                vc_ny.tableIsInteger = false
            }
        }
    }

    
    
    // ---------------------------------------------------------------------------------------
    // ---------------------------------------- CollectionView Delegate ----------------------
    // ---------------------------------------------------------------------------------------
    
    // tell the collection view how many cells to make
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.nrOfAttempts!
    }
    
    // make a cell for each cell index path
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        // get a reference to our storyboard cell
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collectionCellBool", for: indexPath as IndexPath) as! CollectionViewCellBool
        cell.attemptNr.text = String(indexPath.row+1)
        cell.result.image = UIImage(named: "")
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        // handle tap events
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: CGFloat(Float(collectionView.frame.size.width)/Float(nrOfAttempts!)), height: collectionView.frame.size.height);
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    
    
    // ---------------------------------------------------------------------------------------
    // ---------------------------------------- PickerViewDelegate Methods -------------------
    // ---------------------------------------------------------------------------------------
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return idArray!.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return String(idArray![row])
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.updateEquipments(setToActive: -1)
    }
    
    
    
    // ---------------------------------------------------------------------------------------
    // ---------------------------------------- Pop-Ups / Error Messages ---------------------
    // ---------------------------------------------------------------------------------------
    
    func showNotFinishedWithExercise() {
        let notFinishedErrorAlert = UIAlertController(title: "Du är inte klar med övningen", message: "Mata in ett resultat och tryck sedan på 'Nästa' tills du fyllt alla rutor.", preferredStyle: .alert)
        let OKAction = UIAlertAction(title: "OK", style: .default) { (action) in
            // ...
        }
        notFinishedErrorAlert.addAction(OKAction)
        self.present(notFinishedErrorAlert, animated: true) {
            // ...
        }
    }
    
    func showConfirmation() {
        let confirmationAlert = UIAlertController(title: "Du har valt:", message: "ID: " + String(idArray![IDInput.selectedRow(inComponent: 0)]) + "\n Är du nöjd med dina val?", preferredStyle: UIAlertControllerStyle.alert)
        
        let YESAction = UIAlertAction(title: "JA", style: .default) { (action) in
            self.shouldSave = true
            self.performSegue(withIdentifier: "showMenuFromBoolean", sender: self)
        }
        let NOAction = UIAlertAction(title: "NEJ", style: .default) { (action) in
            // Gå tillbaka
        }
        confirmationAlert.addAction(NOAction)
        confirmationAlert.addAction(YESAction)
        self.present(confirmationAlert, animated: true) {
            // ...
        }
    }
    
    func showCancelConfirmation() {
        let cancelAlert = UIAlertController(title: "Är du säker på att du vill gå tillbaka till menyn?", message: "" , preferredStyle: UIAlertControllerStyle.alert)
        let YESAction = UIAlertAction(title: "JA", style: .default) { (action) in
            self.shouldSave = false
            self.performSegue(withIdentifier: "showMenuFromBoolean", sender: self)
        }
        let NOAction = UIAlertAction(title: "NEJ", style: .default) { (action) in
            // Gå tillbaka
        }
        cancelAlert.addAction(NOAction)
        cancelAlert.addAction(YESAction)
        self.present(cancelAlert, animated: true)
    }
    
    
    
    
    
    // Standard method to have here
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
