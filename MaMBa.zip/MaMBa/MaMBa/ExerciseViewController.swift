//
//  ExerciseViewController.swift
//  GoFlow
//
//  Created by Fredrik Beiron on 05/05/16.
//  Copyright © 2016 Fredrik Beiron. All rights reserved.
//

import UIKit
import CoreBluetooth
import Foundation
import AVFoundation // Ljud

class ExerciseViewController: UIViewController, BLEDelegate, ConnectionDelegate, UIPickerViewDataSource, UIPickerViewDelegate, UITextFieldDelegate, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    // --------------------------------------------------------------------------------------
    // ----------------------------------- Variables ----------------------------------------
    // --------------------------------------------------------------------------------------
    
    // Variables that is connected to design elements

    @IBOutlet weak var cancel: UIImageView!
    @IBOutlet weak var startButton: UIImageView!
    @IBOutlet weak var exerciseTitle: UILabel!
    @IBOutlet weak var connectButton: UIImageView!
    @IBOutlet weak var IDInput: UIPickerView!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var prevButton: UIButton!
    @IBOutlet weak var prevArrow: UIImageView!
    @IBOutlet weak var prevText: UILabel!
    // Variables for equipment
    @IBOutlet weak var handImage: UIImageView!
    @IBOutlet weak var footImage: UIImageView!
    @IBOutlet weak var racketImage: UIImageView!
    @IBOutlet weak var clubImage: UIImageView!
    
    let equipmentsTxt = ["hand", "fot", "rack", "klubba", "armbåge", "lår", "slagträ", "huvud"]
    
    var audioPlayerKinect = AVAudioPlayer() // Ljud för kinect
    var audioPlayerKinectDone = AVAudioPlayer()
    
    
    // These gets updated by main menu when the user picks the exercise
    var exerciseTitleVar: String?
    var nrOfAttempts: Int = 10
    var isTimeExercise: Bool = true
    var exerciseNr: Int?
    var isKinectExercise: Bool = true
    var nameID: Int?
    var activeMenuWindow: Int?
    var idArray: [Int]?
    var isFastTurns: Bool?
    var isDropBall: Bool?
    var isBalanceBall: Bool?
    
    // Variables for equipment
    var equipmentChoice: Int?           // hand = 1, foot = 2, racket = 3, club = 4
    var activeEquipments: [[Int]]?        // [1, 1, 0, 0] => only hand and foot can be chosen in this exercise
    var shouldChangeEquipment: [Bool]?
    
    // BLE:
    var ble: BLE!
    var connectStatusBLE:Bool = false
    let ballUUID:String = "9125C031-5A43-1A43-1C02-F13C79A0765B"
    var deviceName:String = "MaMBa-1"// Ändra här för olika övningar, så att man kopplar upp sig med rätt Arduino (någon if-sats...)
    
    // Server
    var conn: Connection!
    var connectStatusServer:Bool = false
    var host: String?
    
    // Other variables
    var isWaitingForValue: Bool = false
    var count: Int = 0
    var isDoneWithAllRep: Bool = false
    var results: [Double]?
    
    
    
    
    // --------------------------------------------------------------------------------------
    // ----------------------------------- View did load ------------------------------------
    // --------------------------------------------------------------------------------------
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.layoutIfNeeded()
        
        self.IDInput.dataSource = self
        self.IDInput.delegate = self
        
        self.collectionView.dataSource = self
        self.collectionView.delegate = self
        
        collectionView.register(UINib(nibName: "CollectionViewCellNum", bundle: nil), forCellWithReuseIdentifier: "collectionCellNum")
        
        do {  // Ljud
            audioPlayerKinect = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "beep", ofType:"mp3")!))
            audioPlayerKinect.prepareToPlay()
        }
            
        catch {
            print(error)
        }
        
        do {  // Ljud
            audioPlayerKinectDone = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "beep2", ofType:"mp3")!))
            audioPlayerKinectDone.prepareToPlay()
        }
            
        catch {
            print(error)
        }
        
        
        
        
        // Buttons
        let tapGestureCancel = UITapGestureRecognizer(target: self, action: #selector(ExerciseViewController.cancelPressed))
        self.cancel.addGestureRecognizer(tapGestureCancel)
        
        let tapGestureStart = UITapGestureRecognizer(target: self, action: #selector(ExerciseViewController.startPressed))
        self.startButton.addGestureRecognizer(tapGestureStart)
        
        let tapToConnectToDevice = UITapGestureRecognizer(target: self, action: #selector(self.connectToDevice))
        self.connectButton.addGestureRecognizer(tapToConnectToDevice)
        
        let tapGestureHand = UITapGestureRecognizer(target: self, action: #selector(self.handPressed))
        self.handImage.addGestureRecognizer(tapGestureHand)
        
        let tapGestureFoot = UITapGestureRecognizer(target: self, action: #selector(self.footPressed))
        self.footImage.addGestureRecognizer(tapGestureFoot)
        
        let tapGestureRacket = UITapGestureRecognizer(target: self, action: #selector(self.racketPressed))
        self.racketImage.addGestureRecognizer(tapGestureRacket)
        
        let tapGestureClub = UITapGestureRecognizer(target: self, action: #selector(self.clubPressed))
        self.clubImage.addGestureRecognizer(tapGestureClub)
        
        let tapGesturePrev = UITapGestureRecognizer(target: self, action: #selector(self.prevPressed))
        self.prevButton.addGestureRecognizer(tapGesturePrev)
        
            

        connectButton.image = #imageLiteral(resourceName: "connect")
        exerciseTitle.text = exerciseTitleVar
        startButton.image = #imageLiteral(resourceName: "start")
        IDInput.selectRow(nameID!, inComponent: 0, animated: true)
        
        
        
        
        // Connection
        if (isKinectExercise) {
            //conn.delegate = self
        } else {
            ble = BLE()
            ble.delegate = self;
        }
        
        if isBalanceBall! { // Balansboll
            deviceName = "MaMBa-1"
        } else if isDropBall! { // Droppboll
            deviceName = "MaMBa-2"
        }
        
            
            
        self.updateEquipments(setToActive: -1)
        
        
    }
    
    
    
    // ---------------------------------------------------------------------------------------
    // ---------------------------------------- Methods --------------------------------------
    // ---------------------------------------------------------------------------------------
    
    func updateEquipments(setToActive: Int) {
        let equipmentImageViews: [UIImageView] = [handImage, footImage, racketImage, clubImage]
        let equipmentImagesON: [UIImage] = [#imageLiteral(resourceName: "handON"),#imageLiteral(resourceName: "footON"),#imageLiteral(resourceName: "racketON"),#imageLiteral(resourceName: "clubON"),#imageLiteral(resourceName: "elbowON"),#imageLiteral(resourceName: "legON"),#imageLiteral(resourceName: "batON"),#imageLiteral(resourceName: "headON")]
        let equipmentImages: [UIImage] = [#imageLiteral(resourceName: "hand"),#imageLiteral(resourceName: "foot"),#imageLiteral(resourceName: "racket"),#imageLiteral(resourceName: "club"),#imageLiteral(resourceName: "elbow"),#imageLiteral(resourceName: "leg"),#imageLiteral(resourceName: "bat"),#imageLiteral(resourceName: "head")]
        let activeID = idArray![IDInput.selectedRow(inComponent: 0)]-1
        var onIsUsed = false
        for i in 0...equipmentImageViews.count-1 {
            if activeEquipments![activeID][i] == 0 {
                equipmentImageViews[i].alpha = 0.2
                if shouldChangeEquipment![i] {
                    equipmentImageViews[i].image = equipmentImages[i+4]
                } else {
                    equipmentImageViews[i].image = equipmentImages[i]
                }
            } else {
                equipmentImageViews[i].alpha = 1.0
                if shouldChangeEquipment![i] {
                    if (onIsUsed || (i < setToActive)) {
                        equipmentImageViews[i].image = equipmentImages[i+4]
                    } else if setToActive == i || setToActive < 0 {
                        equipmentImageViews[i].image = equipmentImagesON[i+4]
                        self.equipmentChoice! = i+1
                        onIsUsed = true
                    }
                } else {
                    if (onIsUsed || (i < setToActive)) {
                        equipmentImageViews[i].image = equipmentImages[i]
                    } else if setToActive == i || setToActive < 0 {
                        equipmentImageViews[i].image = equipmentImagesON[i]
                        self.equipmentChoice! = i+1
                        onIsUsed = true
                    }
                }
            }
        }
    }
    
    func PlayKinect() {
        audioPlayerKinect.play() // Ljud
    }
    
    func PlayKinectDone() {
        audioPlayerKinectDone.play()
    }
    
    
    // ----------------------------------- Small methods -------------------------------------
    
    @objc func SetIsWaitingForValueToFalse() {
        self.isWaitingForValue = false
    }
    
    // Dismiss keyboard when hitting enter after finnished writing:
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
    
    func connectToServer() {
        self.connectButton.image = #imageLiteral(resourceName: "trying")
        conn = Connection()
        conn.delegate = self
        conn.connect(host!, port: 3233)
        Timer.scheduledTimer(timeInterval: 2, target: self, selector: #selector(self.timerStopped), userInfo: nil, repeats: false)
    }
    
    @objc func timerStopped() {
        if !self.connectStatusServer {
            self.connectButton.image = #imageLiteral(resourceName: "connect")
            if (conn != nil) {
                conn.inputStream!.close()
                conn.outputStream!.close()
                conn.inputStream!.remove(from: .main, forMode: RunLoopMode.defaultRunLoopMode)
                conn.outputStream!.remove(from: .main, forMode: RunLoopMode.defaultRunLoopMode)
                conn = nil
            }
            self.showServerOfflineErrorAlert()
        }
    }
    
    func sendBLEData(_ data:String) {
        if (ble.activePeripheral?.state == CBPeripheralState.connected) {
            ble.write(data: data.data(using: String.Encoding.utf8)!)
        } else {
            showBLEDisconnectErrorAlert()
        }
    }
    
    func getAverage() -> Double {
        var sum: Double = 0
        for i in 0...nrOfAttempts-1 {
            sum += results![i]
        }
        var average: Double = 0
        if isDoneWithAllRep {
            average = sum/(Double(nrOfAttempts))
        } else {
            average = sum/(Double(count+1))
        }
        return average
    }
    
    func getTotal() -> Double {
        var sum: Double = 0
        for i in 0...nrOfAttempts-1 {
            sum += results![i]
        }
        return sum
    }
    
    func getR(_ x: Double, y: Double) -> Double {
        return sqrt(pow(x, 2)+pow(y,2))
    }

    
    
    // ---------------------------------------------------------------------------------------
    // ---------------------------------------- Button pressed methods -----------------------
    // ---------------------------------------------------------------------------------------
    
    // ------------------------------ Choose equipment -----------------------------
    // Runs when the user taps the different equipments
    @objc func handPressed() {
        let activeID = idArray![IDInput.selectedRow(inComponent: 0)]-1
        if activeEquipments![activeID][0] == 1 {
            self.updateEquipments(setToActive: 0)
            equipmentChoice = 1
        }
    }
    
    @objc func footPressed() {
        let activeID = idArray![IDInput.selectedRow(inComponent: 0)]-1
        if activeEquipments![activeID][1] == 1 {
            self.updateEquipments(setToActive: 1)
            equipmentChoice = 2
        }
    }
    
    @objc func racketPressed() {
        let activeID = idArray![IDInput.selectedRow(inComponent: 0)]-1
        if activeEquipments![activeID][2] == 1 {
            self.updateEquipments(setToActive: 2)
            equipmentChoice = 3
        }
    }
    
    @objc func clubPressed() {
        let activeID = idArray![IDInput.selectedRow(inComponent: 0)]-1
        if activeEquipments![activeID][3] == 1 {
            self.updateEquipments(setToActive: 3)
            equipmentChoice = 4
        }
    }
    
    @objc func prevPressed() {
        if count > 0 {
            let cell = (collectionView!.cellForItem(at: IndexPath(row: count-1, section: 0)) as! CollectionViewCellNum)
            cell.result.text = ""
            results![count-1] = 0.0
            count = count - 1
            isDoneWithAllRep = false
            isWaitingForValue = false
            startButton.image = #imageLiteral(resourceName: "start")
        }
    }
    
    // ------------------------------ Connect to BLE or server -----------------------------
    // Runs when the user taps the connect button.
    @objc func connectToDevice() {
        if (isKinectExercise) {
            if (!self.connectStatusServer) {
                showConnectToServerQuestion() // asks which server to connect to
            } else {
                showEndConnection()
            }
        } else {  // is BLE exercise
            if (!self.connectStatusBLE) {   // Are we connected?
                self.connectButton.image = #imageLiteral(resourceName: "trying")
                
                if (ble.activePeripheral != nil) {  // is it conneced to something? Then cancel that connection!
                    if (ble.activePeripheral?.state == CBPeripheralState.connected) {
                        ble.centralManager.cancelPeripheralConnection(ble.activePeripheral!)
                        //return
                    }
                }
                if (!ble.peripherals.isEmpty) {  // Remove all units if there is any
                    ble.peripherals.removeAll()
                }
                
                //ble.findServiceFromUUID("9125C031-5A43-1A43-1C02-F13C79A0765B", p: <#T##CBPeripheral!#>)
                
                let didScan = ble.startScanning(timeout: 2, device: deviceName)  // Start scanning for units with the name deviceName
                if(didScan) {
                    // ..
                }
                
            } else {
                showEndConnection()
            }
        }
    }
    
    
    // ------------------------------ Cancel was pressed -----------------------------
    // Runs when the user taps the cancel button.
    @objc func cancelPressed() {
        self.showCancelConfirmation()
    }
    
    
    // ------------------------------ Start was pressed -----------------------------
    // Runs when the user taps the start button.
    @objc func startPressed() {
        if (!isWaitingForValue) {
            if (connectStatusServer || connectStatusBLE) {
                if (count == 0) {
                    let tempArr = Array(repeating: 0.0, count: self.nrOfAttempts)
                    results = tempArr
                } else if (count == nrOfAttempts-1) {
                    isDoneWithAllRep = true
                } else if (isDoneWithAllRep) {
                    self.showConfirmation()
                }
                if (count < nrOfAttempts) {
                    let str: String = NSString(format: "%d", 2) as String // Skickar alltid med 2.
                    if (connectStatusServer) {
                        conn.sendData(str)
                        print("Send 2")
                    } else if (connectStatusBLE) {
                        let data:Data = (str as NSString).data(using: String.Encoding.utf8.rawValue)!
                        ble.write(data: data)
                    }
                }
                if (count == nrOfAttempts) {
                    isDoneWithAllRep = true
                } else {
                    isWaitingForValue = true
                    startButton.image = #imageLiteral(resourceName: "waiting")
                }
            } else {
                if isKinectExercise {
                    showServerNotConnectedErrorAlert()
                } else {
                    showBLENotConnectedErrorAlert()
                }
            }
        } else {
            if isDropBall! && connectStatusBLE {
                let str: String = NSString(format: "%d", 4) as String
                let data:Data = (str as NSString).data(using: String.Encoding.utf8.rawValue)!
                ble.write(data: data)
                print("4")
            }
        }
    }
    
    
    
    // ---------------------------------------------------------------------------------------
    // ---------------------------------------- Prepare for segue ----------------------------
    // ---------------------------------------------------------------------------------------
    // Send data to the main menu when exiting or finished with exercise
    
    // Go back to the main menu
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "showMenu") {
            let vc_ny = (segue.destination as! ViewController)
            //vc_ny.equipmentChoice = self.equipmentChoice!
            if isDoneWithAllRep {
                vc_ny.tableName = String(idArray![IDInput.selectedRow(inComponent: 0)])
                vc_ny.data = results
                vc_ny.addToTableBool = isDoneWithAllRep
                vc_ny.tableImage = UIImage(named: String(format: "tblOvn%d", exerciseNr!))
                vc_ny.tableExercise = exerciseTitleVar
                vc_ny.tableExerciseNr = exerciseNr!
                
                if shouldChangeEquipment![equipmentChoice!-1] {
                    vc_ny.tableEquipmentTxt = equipmentsTxt[equipmentChoice!+4-1]
                    vc_ny.tableEquipment = UIImage(named: String(format: "tblEqu%d", equipmentChoice!+4))
                } else {
                    vc_ny.tableEquipmentTxt = equipmentsTxt[equipmentChoice!-1]
                    vc_ny.tableEquipment = UIImage(named: String(format: "tblEqu%d", equipmentChoice!))
                }
                
                if isTimeExercise {
                    vc_ny.tableResult = String(format: "%.1f s", getAverage())
                    vc_ny.tableIsInteger = false
                } else {
                    vc_ny.tableResult = String(format: "%.1f", getAverage())
                    vc_ny.tableIsInteger = true
                }
                vc_ny.tableEquipmentDir = ""
            }
            vc_ny.host = self.host!
            vc_ny.nameID = IDInput.selectedRow(inComponent: 0)
            vc_ny.activeMenuWindow = self.activeMenuWindow!
            
            if (connectStatusBLE) {
                ble.centralManager.cancelPeripheralConnection(ble.activePeripheral!)
            }
        }
    }

    
    
    // ---------------------------------------------------------------------------------------
    // ---------------------------------------- BLE or Server did Receive a value ------------
    // ---------------------------------------------------------------------------------------
    // Update screen when an exercise is done
    
    
    // ---------------------------------------- BLE ------------------------------------------
    
    func bleDidReceiveData(receivedData: Data) {
        if (isWaitingForValue) {
            // converts the bytes to a float
            let bytes:[UInt8] = Array(receivedData)
            var value:Float = 0.0
            memcpy(&value, bytes, 4)
            print("Received Value: \(value)")
            
            let time:Double = Double(value)
            
            results?[count] = time
            //averageNumber.text = String(format: "%.1f s", getAverage())
            
            let cell = (collectionView!.cellForItem(at: IndexPath(row: count, section: 0)) as! CollectionViewCellNum)
            if isTimeExercise {
                cell.result.text = String(Double(round((results?[count])!*100)/100))
            } else {
                cell.result.text = String(Int((results?[count])!))
            }
            
            Timer.scheduledTimer(timeInterval: 2.0, target: self, selector: #selector(ExerciseViewController.SetIsWaitingForValueToFalse), userInfo: nil, repeats: false)
            //isWaitingForValue = false
            
            if (count != nrOfAttempts-1) {
                self.startButton.image = #imageLiteral(resourceName: "start")
            } else {
                self.startButton.image = #imageLiteral(resourceName: "saveData")
                isWaitingForValue = false
            }
            
            count += 1
            print(count)
            print(isWaitingForValue)
        }
    }

    
    // ---------------------------------------- Server ---------------------------------------
    
    func serverDidReceiveValue(_ sender: Connection, dataMsg: String) {
        if (isWaitingForValue) {
            if count != nrOfAttempts - 1 {
                //PlayKinect()
            } else {
                PlayKinectDone()
            }
            print("Received Value")
            if (dataMsg != "") {
                print(dataMsg)
                if (isTimeExercise) { // ---------------------------------------------- Tidsövning
                    
                    let time = (dataMsg as NSString).doubleValue
                    
                    results?[count] = time
                    
                    //averageNumber.text = String(format: "%.1f s", getAverage())
                    
                    
                    let cell = (collectionView!.cellForItem(at: IndexPath(row: count, section: 0)) as! CollectionViewCellNum)
                    cell.result.text = String(Double(round((results?[count])!*100)/100))
                    
                    
                    
                    
                    if isFastTurns! {
                        isWaitingForValue = true
                        if (count == nrOfAttempts-1) {
                            isDoneWithAllRep = true
                            isWaitingForValue = false
                        }
                    }
                    
                    
                }
                
                if (count != nrOfAttempts-1 && !isFastTurns!) {
                    self.startButton.image = #imageLiteral(resourceName: "start")
                } else if (count != nrOfAttempts-1) {
                    self.startButton.image = #imageLiteral(resourceName: "waiting")
                } else {
                    self.startButton.image = #imageLiteral(resourceName: "saveData")
                }
                count += 1
            }
        }
    }

    
    // ---------------------------------------------------------------------------------------
    // ---------------------------------------- CollectionView Delegate ----------------------
    // ---------------------------------------------------------------------------------------
    
    // tell the collection view how many cells to make
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.nrOfAttempts
    }
    
    // make a cell for each cell index path
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        // get a reference to our storyboard cell
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collectionCellNum", for: indexPath as IndexPath) as! CollectionViewCellNum
        cell.attemptNr.text = String(indexPath.row+1)
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        // handle tap events
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: CGFloat(Float(collectionView.frame.size.width)/Float(nrOfAttempts)), height: collectionView.frame.size.height);
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    
    
    // ---------------------------------------------------------------------------------------
    // ---------------------------------------- PickerViewDelegate Methods -------------------
    // ---------------------------------------------------------------------------------------
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return idArray!.count;
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return String(idArray![row])
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.updateEquipments(setToActive: -1)
    }

    
    
    
    
    
    
    
    
    
    // ------------------------------------------------------------------------------------------------------------
    // ------------------------------------------------------------------------------------------------------------
    // ---------------------------------------- The code below is not that important to change --------------------
    // ------------------------------------------------------------------------------------------------------------
    // ------------------------------------------------------------------------------------------------------------
    // Just BLE-delegate, Server-delegate and pop-up's  ( didReceive-delegates are above )
    
    
    // ---------------------------------------------------------------------------------------
    // ---------------------------------------- Server Methods - Delegate --------------------
    // ---------------------------------------------------------------------------------------
    
    
    func serverDidConnect(_ sender: Connection, stream: Stream) {
        if (stream is InputStream) {
            self.connectButton.image = #imageLiteral(resourceName: "connected")
            self.connectStatusServer = true
            print("Input delegate works!")
        } else if (stream is OutputStream) {
            print("Output delegate works!")
        }
    }
    
    func serverIsOffline(_ sender: Connection, s: String) {
        self.startButton.image = #imageLiteral(resourceName: "start")
        if (conn != nil) {
            conn.inputStream!.close()
            conn.outputStream!.close()
            conn.inputStream!.remove(from: .main, forMode: RunLoopMode.defaultRunLoopMode)
            conn.outputStream!.remove(from: .main, forMode: RunLoopMode.defaultRunLoopMode)
            conn = nil
        }
        print(s)
        showServerOfflineErrorAlert()
    }
    
    func serverDidDisconnect(_ sender: Connection, s: String) {
        self.connectButton.image = #imageLiteral(resourceName: "connect")
        self.connectStatusServer = false
        self.startButton.image = #imageLiteral(resourceName: "start")
        if (conn != nil) {
            conn.inputStream!.close()
            conn.outputStream!.close()
            conn.inputStream!.remove(from: .main, forMode: RunLoopMode.defaultRunLoopMode)
            conn.outputStream!.remove(from: .main, forMode: RunLoopMode.defaultRunLoopMode)
            conn = nil
        }
        print(s)
        showServerDisconnectErrorAlert()
    }
    
    
    
    // ---------------------------------------------------------------------------------------
    // ---------------------------------------- BLE Methods - Delegate -----------------------
    // ---------------------------------------------------------------------------------------
    
    //func bleDidUpdateState() {    // not used ..?
    //}
    
    func bleDidConnect() {
        self.connectButton.image = #imageLiteral(resourceName: "connected")
        connectStatusBLE = true
    }
    
    func bleDidDisconnect() {
        showBLEDisconnectErrorAlert()
        connectStatusBLE = false
        self.connectButton.image = #imageLiteral(resourceName: "connect")
    }
    
    func bleDidFailToConnect() {
        self.showBLECouldNotConnectErrorAlert()
        self.connectButton.image = #imageLiteral(resourceName: "connect")
    }
    
    func bleDidNotFindPeripheral() {
        self.showBLECouldNotFindErrorAlert()
        self.connectButton.image = #imageLiteral(resourceName: "connect")
    }
    

    
    // ---------------------------------------------------------------------------------------
    // ---------------------------------------- POP-UP Messages ------------------------------
    // ---------------------------------------------------------------------------------------
    
    
    func showConnectToServerQuestion() {
        let connectToServerQuestion = UIAlertController(title: ("Anslut till adress: ''" + self.host! + "''?"), message: "Vill du ansluta till den här adressen eller en annan?", preferredStyle: .alert)
        let YESAction = UIAlertAction(title: "JA", style: .default) { (action) in
            self.connectToServer()
        }
        let OTHERAction = UIAlertAction(title: "ANNAN", style: .default) { (action) in
            self.showConnectToOtherServer()
        }
        connectToServerQuestion.addAction(OTHERAction)
        connectToServerQuestion.addAction(YESAction)
        self.present(connectToServerQuestion, animated: true) {
            // ...
        }
    }
    
    func showConnectToOtherServer() {
        let connectToOtherServer = UIAlertController(title: "Anslut till värd", message: "", preferredStyle: UIAlertControllerStyle.alert)
        
        let connectAction = UIAlertAction(title: "Anslut", style: UIAlertActionStyle.default, handler: {
            alert -> Void in
            
            let textField = connectToOtherServer.textFields![0] as UITextField
            self.host = textField.text!
            self.connectToServer()
        })
        
        let cancelAction = UIAlertAction(title: "Avbryt", style: UIAlertActionStyle.default, handler: {
            (action : UIAlertAction!) -> Void in
            
        })
        
        connectToOtherServer.addTextField { (textField : UITextField!) -> Void in
            textField.placeholder = "Skriv in adress"
        }
        
        connectToOtherServer.addAction(connectAction)
        connectToOtherServer.addAction(cancelAction)
        
        self.present(connectToOtherServer, animated: true, completion: nil)
    }
    
    func showConfirmation() {
        var confirmationAlert = UIAlertController(title: "Du har valt:", message: "ID: " + String(self.idArray![self.IDInput.selectedRow(inComponent: 0)]) + "\n Är du nöjd med dina val?", preferredStyle: UIAlertControllerStyle.alert)
        if isFastTurns! {
            confirmationAlert = UIAlertController(title: "Du har valt:", message: "ID: " + String(self.idArray![self.IDInput.selectedRow(inComponent: 0)]) + "\n" + "Utrustning: " + self.equipmentsTxt[self.equipmentChoice!-1] + "\n Är du nöjd med dina val?", preferredStyle: UIAlertControllerStyle.alert)
        }
        
        let YESAction = UIAlertAction(title: "JA", style: .default) { (action) in
            self.performSegue(withIdentifier: "showMenu", sender: self)
        }
        let NOAction = UIAlertAction(title: "NEJ", style: .default) { (action) in
            // Gå tillbaka
        }
        confirmationAlert.addAction(NOAction)
        confirmationAlert.addAction(YESAction)
        self.present(confirmationAlert, animated: true) {
            // ...
        }
    }
    
    func showEndConnection() {
        let endConnectionAlert = UIAlertController(title: "Vill du avbryta anslutningen?", message: "" , preferredStyle: UIAlertControllerStyle.alert)
        let YESAction = UIAlertAction(title: "JA", style: .default) { (action) in
            if self.isKinectExercise {
                // disconnect server
                self.conn.inputStream!.close()
                self.conn.outputStream!.close()
                self.conn.inputStream!.remove(from: .main, forMode: RunLoopMode.defaultRunLoopMode)
                self.conn.outputStream!.remove(from: .main, forMode: RunLoopMode.defaultRunLoopMode)
                self.conn = nil
                self.connectButton.image = #imageLiteral(resourceName: "connect")
                self.connectStatusServer = false
                if self.isWaitingForValue {
                    self.isWaitingForValue = false
                    self.startButton.image = #imageLiteral(resourceName: "start")
                }
            } else {
                _ = self.ble.disconnect(peripheral: self.ble.activePeripheral!)
                self.connectButton.image = #imageLiteral(resourceName: "connect")
                self.connectStatusBLE = false
                if self.isWaitingForValue {
                    self.isWaitingForValue = false
                    self.startButton.image = #imageLiteral(resourceName: "start")
                }
            }
        }
        let NOAction = UIAlertAction(title: "NEJ", style: .default) { (action) in
            // Gå tillbaka
        }
        endConnectionAlert.addAction(NOAction)
        endConnectionAlert.addAction(YESAction)
        self.present(endConnectionAlert, animated: true) {
            // ...
        }
    }
    
    func showCancelConfirmation() {
        let cancelAlert = UIAlertController(title: "Är du säker på att du vill gå tillbaka till menyn?", message: "" , preferredStyle: UIAlertControllerStyle.alert)
        let YESAction = UIAlertAction(title: "JA", style: .default) { (action) in
            if (self.conn != nil) {
                self.conn.inputStream!.close()
                self.conn.outputStream!.close()
                self.conn.inputStream!.remove(from: .main, forMode: RunLoopMode.defaultRunLoopMode)
                self.conn.outputStream!.remove(from: .main, forMode: RunLoopMode.defaultRunLoopMode)
                self.conn = nil
            }
            self.isDoneWithAllRep = false
            self.performSegue(withIdentifier: "showMenu", sender: self)
        }
        let NOAction = UIAlertAction(title: "NEJ", style: .default) { (action) in
            // Gå tillbaka
        }
        cancelAlert.addAction(NOAction)
        cancelAlert.addAction(YESAction)
        self.present(cancelAlert, animated: true)
    }
    
    
    
    
    // ------------------------------------ Error messages ----------------------------------
    
    func showServerDisconnectErrorAlert() {
        let serverDisconnectErrorAlert = UIAlertController(title: "Förlorade anslutning till servern", message: "Du förlorade anslutningen till datorn. Var god kontrollera programmet och försök sedan att ansluta igen.", preferredStyle: .alert)
        let OKAction = UIAlertAction(title: "OK", style: .default) { (action) in
            // ...
        }
        serverDisconnectErrorAlert.addAction(OKAction)
        self.present(serverDisconnectErrorAlert, animated: true) {
            // ...
        }
    }
    
    func showServerOfflineErrorAlert() {
        let serverOfflineErrorAlert = UIAlertController(title: "Servern är offline", message: "Servern är offline. Var god kontrollera programmet och försök sedan att ansluta igen.", preferredStyle: .alert)
        let OKAction = UIAlertAction(title: "OK", style: .default) { (action) in
            // ...
        }
        serverOfflineErrorAlert.addAction(OKAction)
        self.present(serverOfflineErrorAlert, animated: true) {
            // ...
        }
    }
    
    func showBLEDisconnectErrorAlert() {
        let BLEDisconnectErrorAlert = UIAlertController(title: "Förlorade anslutning till enhet", message: "Du förlorade anslutning till bluetooth. Var god kontrollera bluetooth-inställningar och försök sedan att ansluta igen.", preferredStyle: .alert)
        let OKAction = UIAlertAction(title: "OK", style: .default) { (action) in
            // ...
        }
        BLEDisconnectErrorAlert.addAction(OKAction)
        self.present(BLEDisconnectErrorAlert, animated: true) {
            // ...
        }
    }
    
    func showBLECouldNotFindErrorAlert() {
        let BLECouldNotFindErrorAlert = UIAlertController(title: "Kunde inte hitta någon enhet", message: "Kunde inte hitta bluetooth-anslutning. Var god kontrollera enheten du försöker ansluta till och försök igen.", preferredStyle: .alert)
        let OKAction = UIAlertAction(title: "OK", style: .default) { (action) in
            // ...
        }
        BLECouldNotFindErrorAlert.addAction(OKAction)
        self.present(BLECouldNotFindErrorAlert, animated: true) {
            // ...
        }
    }
    
    func showBLECouldNotConnectErrorAlert() {
        let BLECouldNotConnectErrorAlert = UIAlertController(title: "Kunde inte ansluta till bluetooth", message: "Kunde inte ansluta till bluetooth. Var god kontrollera inställningar and försök sedan att ansluta igen.", preferredStyle: .alert)
        let OKAction = UIAlertAction(title: "OK", style: .default) { (action) in
            // ...
        }
        BLECouldNotConnectErrorAlert.addAction(OKAction)
        self.present(BLECouldNotConnectErrorAlert, animated: true) {
            // ...
        }
    }
    
    func showServerNotConnectedErrorAlert() {
        let serverNotConnectedErrorAlert = UIAlertController(title: "Du är inte ansluten till servern.", message: " Var god och anslut genom att trycka på 'Anslut'.", preferredStyle: .alert)
        let OKAction = UIAlertAction(title: "OK", style: .default) { (action) in
            // ...
        }
        serverNotConnectedErrorAlert.addAction(OKAction)
        self.present(serverNotConnectedErrorAlert, animated: true) {
            // ...
        }
    }
    
    func showBLENotConnectedErrorAlert() {
        let BLENotConnectedErrorAlert = UIAlertController(title: "Du är inte ansluten till bluetooth.", message: " Var god och anslut genom att trycka på 'Anslut'.", preferredStyle: .alert)
        let OKAction = UIAlertAction(title: "OK", style: .default) { (action) in
            // ...
        }
        BLENotConnectedErrorAlert.addAction(OKAction)
        self.present(BLENotConnectedErrorAlert, animated: true) {
            // ...
        }
    }
    func showNotAValidNumberErrorAlert() {
        let notAValidNumberErrorAlert = UIAlertController(title: "Ej giltligt antal repetitioner.", message: "Ändra till ett giltligt antal och försök igen.", preferredStyle: .alert)
        let OKAction = UIAlertAction(title: "OK", style: .default) { (action) in
            // ...
        }
        notAValidNumberErrorAlert.addAction(OKAction)
        self.present(notAValidNumberErrorAlert, animated: true) {
            // ...
        }
    }
    
    
    
    
    
    // Standard method to have here
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
