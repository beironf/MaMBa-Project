//
//  ViewController.swift
//  GoFlow
//
//  Created by Fredrik Beiron on 05/05/16.
//  Copyright © 2016 Fredrik Beiron. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIScrollViewDelegate, TableDelegate {
    
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var pageControl: UIPageControl!
    
    var exerciseTitle: String?
    var isTimeExercise: Bool = true
    var exerciseNr: Int?
    var isKinectExercise: Bool = true
    var isAutomatedExercise: Bool = true
    var isIntegerExercise: Bool = true
    var isBooleanExercise: Bool = true
    var host: String = "192.168.43.24"
    var activeEquipments: [[Int]]?
    var nameID: Int = 0
    var equipmentChoice: Int = 1    // hand = 1, foot = 2, racket = 3, club = 4
    var nrOfAttempts: Int = 5
    var activeMenuWindow: Int = 1
    var isTimerExercise: Bool = true
    var idArray: [[Int]]?
    var pickerArray: [Int]?
    
    var isFastTurns: Bool = false
    var isDropBall: Bool = false
    var isBalanceBall: Bool = false
    var isMiniGolf: Bool = false
    
    // Table variables
    var addToTableBool: Bool = false
    var tableName: String?
    var tableResult: String?
    var tableImage: UIImage?
    var data: Any?
    var tableExercise: String?
    var tableExerciseNr: Int?
    var tableEquipment: UIImage?
    var tableEquipmentTxt: String?
    var tableEquipmentDir: String?
    var tableIsInteger: Bool?
    
    // Equipment variables
    // exerciseNr:                     #1          #2          #3         #4        #5         #6          #7         #8   ...
    let equipmentsArray: [[Int]] = [[0,1,0,1], [0,0,1,0], [0,0,1,0], [1,0,0,0], [1,0,0,0], [0,1,0,0], [0,0,0,1], [0,1,0,0], [1,0,0,0], [0,0,1,0], [0,0,0,1], [0,0,0,0], [0,0,0,0], [0,0,0,0], [0,0,0,0], [0,0,0,0], [0,0,0,0], [0,0,0,0]]
    var activeEquipmentsArray: [[[Int]]] = [[[]]]
    var shouldChangeEquipment: [Bool] = [false,false,false,false]   // example:  if [0] == true  then hand image becomes elbow
    
    let equipmentsTxt = ["hand", "fot", "rack", "klubba", "armbåge", "lår", "slagträ", "huvud"]
    
    // Server
    var conn: Connection!
    var connectStatusServer = false
    
    
    let vc0 = ViewController0(nibName: "ViewController0", bundle: nil)
    let vc1 = ViewController1(nibName: "ViewController1", bundle: nil)
    let vc2 = ViewController2(nibName: "ViewController2", bundle: nil)
    let vc3 = ViewController3(nibName: "ViewController3", bundle: nil)
    let vc4 = ViewController4(nibName: "ViewController4", bundle: nil)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.layoutIfNeeded()
        
        self.vc0.delegate = self
        
        makeLayout()
        setUpScroll()
        makeRecognizer()
        setNamesForExercises()
        
        if addToTableBool == true {
            if let tblData = data as? [Double] {
                self.vc0.addTableItemNum(self.tableName!, tblResult: self.tableResult!, tblImage: self.tableImage!, tblEquipment: tableEquipment!, tblEquipmentTxt: tableEquipmentTxt!, tblEquipmentDir: self.tableEquipmentDir!, data: tblData, exercise: self.tableExercise!, exerciseNr: self.tableExerciseNr!, isInteger: self.tableIsInteger!)
            } else if let tblData = data as? [Bool] {
                self.vc0.addTableItemBool(self.tableName!, tblResult: self.tableResult!, tblImage: self.tableImage!, tblEquipment: tableEquipment!, tblEquipmentTxt: tableEquipmentTxt!, data: tblData, exercise: self.tableExercise!, exerciseNr: self.tableExerciseNr!, isInteger: self.tableIsInteger!)
            }
            
        }
        
        pageControl.currentPage = activeMenuWindow
        
        self.updateArrays()
        
    }
    
    func updateArrays() {
        // Create Arrays
        idArray = Array(repeating: Array(1...500), count: 18)
        activeEquipmentsArray = [[[]]]
        for _ in 1...17 {
            activeEquipmentsArray.append([[]])
        }
        for i in 0...17 {
            activeEquipmentsArray[i][0] = equipmentsArray[i]
            for _ in 1...499 {
                self.activeEquipmentsArray[i].append(equipmentsArray[i])
            }
        }
        
        // Remove used equipments in table
        if vc0.tableItems.count > 0 {
            for i in 0...vc0.tableItems.count-1 {
                if let item = vc0.tableItems[i] as? TableItemNumeric {
                    let temp = activeEquipmentsArray[item.exerciseNr-1][Int(item.name)!-1]
                    for j in 0...temp.count-1 {
                        if temp[j] == 1 && (item.equipment_txt == equipmentsTxt[j] || item.equipment_txt == equipmentsTxt[j+4]) {
                            activeEquipmentsArray[item.exerciseNr-1][Int(item.name)!-1][j] = 0
                        }
                    }
                } else if let item = vc0.tableItems[i] as? TableItemBoolean {
                    let temp = activeEquipmentsArray[item.exerciseNr-1][Int(item.name)!-1]
                    for j in 0...temp.count-1 {
                        if temp[j] == 1 && (item.equipment_txt == equipmentsTxt[j] || item.equipment_txt == equipmentsTxt[j+4]) {
                            activeEquipmentsArray[item.exerciseNr-1][Int(item.name)!-1][j] = 0
                        }
                    }
                }
            }
        }
        
        // Remove id's from idArray if they already has been used (all equipments are used)
        for i in 0...activeEquipmentsArray.count-1 {
            var nrOfErased = 0
            for j in 0...activeEquipmentsArray[i].count-1 {
                if activeEquipmentsArray[i][activeEquipmentsArray[i].count-j-1].reduce(0,+) == 0 {
                    idArray![i].remove(at: idArray![i].count-(j-nrOfErased)-1)
                    nrOfErased = nrOfErased + 1
                }
            }
        }
        
        // Update text if something gets erased or added to the result list
        self.vc0.eraseAllText.text = String(format: "Radera alla (%d st)", self.vc0.tableItems.count)
    }

    
    
    
    func makeRecognizer() {
        let tapGesture1 = UITapGestureRecognizer(target: self, action: #selector(self.exerciseButtonPressed1))
        let tapGesture2 = UITapGestureRecognizer(target: self, action: #selector(self.exerciseButtonPressed2))
        let tapGesture3 = UITapGestureRecognizer(target: self, action: #selector(self.exerciseButtonPressed3))
        let tapGesture4 = UITapGestureRecognizer(target: self, action: #selector(self.exerciseButtonPressed4))
        let tapGesture5 = UITapGestureRecognizer(target: self, action: #selector(self.exerciseButtonPressed5))
        let tapGesture6 = UITapGestureRecognizer(target: self, action: #selector(self.exerciseButtonPressed6))
        let tapGesture7 = UITapGestureRecognizer(target: self, action: #selector(self.exerciseButtonPressed7))
        let tapGesture8 = UITapGestureRecognizer(target: self, action: #selector(self.exerciseButtonPressed8))
        let tapGesture9 = UITapGestureRecognizer(target: self, action: #selector(self.exerciseButtonPressed9))
        let tapGesture10 = UITapGestureRecognizer(target: self, action: #selector(self.exerciseButtonPressed10))
        let tapGesture11 = UITapGestureRecognizer(target: self, action: #selector(self.exerciseButtonPressed11))
        /*let tapGesture12 = UITapGestureRecognizer(target: self, action: #selector(self.exerciseButtonPressed12))
        let tapGesture13 = UITapGestureRecognizer(target: self, action: #selector(self.exerciseButtonPressed13))
        let tapGesture14 = UITapGestureRecognizer(target: self, action: #selector(self.exerciseButtonPressed14))
        let tapGesture15 = UITapGestureRecognizer(target: self, action: #selector(self.exerciseButtonPressed15))
        let tapGesture16 = UITapGestureRecognizer(target: self, action: #selector(self.exerciseButtonPressed16))
        let tapGesture17 = UITapGestureRecognizer(target: self, action: #selector(self.exerciseButtonPressed17))*/
        //let tapGesture18 = UITapGestureRecognizer(target: self, action: #selector(self.exerciseButtonPressed18))
        self.vc2.ovn1.addGestureRecognizer(tapGesture1)
        self.vc2.ovn2.addGestureRecognizer(tapGesture2)
        self.vc2.ovn3.addGestureRecognizer(tapGesture3)
        self.vc2.ovn4.addGestureRecognizer(tapGesture4)
        self.vc2.ovn5.addGestureRecognizer(tapGesture5)
        self.vc2.ovn6.addGestureRecognizer(tapGesture6)
        self.vc3.ovn7.addGestureRecognizer(tapGesture7)
        self.vc3.ovn8.addGestureRecognizer(tapGesture8)
        self.vc3.ovn9.addGestureRecognizer(tapGesture9)
        self.vc3.ovn10.addGestureRecognizer(tapGesture10)
        self.vc3.ovn11.addGestureRecognizer(tapGesture11)
        /*self.vc3.ovn12.addGestureRecognizer(tapGesture12)
        self.vc4.ovn13.addGestureRecognizer(tapGesture13)
        self.vc4.ovn14.addGestureRecognizer(tapGesture14)
        self.vc4.ovn15.addGestureRecognizer(tapGesture15)
        self.vc4.ovn16.addGestureRecognizer(tapGesture16)
        self.vc4.ovn17.addGestureRecognizer(tapGesture17)*/
        //self.vc4.ovn18.addGestureRecognizer(tapGesture18)
    }
    
    func setNamesForExercises() {
        let nrLabels: [UILabel] = [vc2.ovnNr1, vc2.ovnNr2, vc2.ovnNr3, vc2.ovnNr4, vc2.ovnNr5, vc2.ovnNr6, vc3.ovnNr7, vc3.ovnNr8, vc3.ovnNr9, vc3.ovnNr10, vc3.ovnNr11, vc3.ovnNr12, vc4.ovnNr13, vc4.ovnNr14, vc4.ovnNr15, vc4.ovnNr16, vc4.ovnNr17, vc4.ovnNr18]
        for i in 1...nrLabels.count {
            nrLabels[i-1].text = String(i)
        }
        
        vc2.ovnLabel1.text = "Snabba vändningar"
        vc2.ovnLabel2.text = "Bommen"
        vc2.ovnLabel3.text = "Droppboll"
        vc2.ovnLabel4.text = "Trixa med armbåge"
        vc2.ovnLabel5.text = "Kasta och fånga"
        vc2.ovnLabel6.text = "Jonglera mot vägg"
        vc3.ovnLabel7.text = "Kanonen"
        vc3.ovnLabel8.text = "Jonglera med knä"
        vc3.ovnLabel9.text = "Studsa basket"
        vc3.ovnLabel10.text = "Balansera bollen"
        vc3.ovnLabel11.text = "Minigolf"
        vc3.ovnLabel12.text = "Golfslaget"
        vc4.ovnLabel13.text = "Chippa i mål"
        vc4.ovnLabel14.text = "Valla i mål"
        vc4.ovnLabel15.text = "Bakom nacken"
        vc4.ovnLabel16.text = "Träffa konen"
        vc4.ovnLabel17.text = "Stegen"
        vc4.ovnLabel18.text = "Låga studsar"
        
    }
    
    @objc func exerciseButtonPressed1() { // Kinectövning. Fötter och klubba
        activeEquipments = activeEquipmentsArray[0]
        shouldChangeEquipment = [false,false,false,false]
        nrOfAttempts = 10
        exerciseTitle = "Snabba vändningar"
        isTimeExercise = true
        exerciseNr = 1
        isKinectExercise = true
        isTimerExercise = false
        isFastTurns = true
        equipmentChoice = 2
        self.performSegue(withIdentifier: "showExercise", sender: self)
    }
    @objc func exerciseButtonPressed2() {  // Bommen. Racket
        exerciseTitle = "Tennisboll över bom"
        activeEquipments = activeEquipmentsArray[1]
        shouldChangeEquipment = [false,false,false,false]
        equipmentChoice = 3
        nrOfAttempts = 1
        exerciseNr = 2
        isTimerExercise = true
        pickerArray = Array(0...200)
        self.performSegue(withIdentifier: "showInteger", sender: self)
    }
    @objc func exerciseButtonPressed3() {  // Droppboll. Racket
        activeEquipments = activeEquipmentsArray[2]
        shouldChangeEquipment = [false,false,false,false]
        equipmentChoice = 3
        nrOfAttempts = 7
        exerciseTitle = "Droppboll"
        isTimeExercise = true
        exerciseNr = 3
        isKinectExercise = false
        isTimerExercise = false
        isDropBall = true
        self.performSegue(withIdentifier: "showExercise", sender: self)
    }
    @objc func exerciseButtonPressed4() { // Jonglera. Armbåge
        exerciseTitle = "Jonglera med armbåge"
        activeEquipments = activeEquipmentsArray[3]
        shouldChangeEquipment = [true,false,false,false]
        nrOfAttempts = 3
        exerciseNr = 4
        equipmentChoice = 1
        isTimerExercise = false
        pickerArray = Array(0...30)
        self.performSegue(withIdentifier: "showInteger", sender: self)
    }
    @objc func exerciseButtonPressed5() { // Kasta-fånga mot vägg. Händer
        activeEquipments = activeEquipmentsArray[4]
        shouldChangeEquipment = [false,false,false,false]
        nrOfAttempts = 2
        exerciseTitle = "Kasta och fånga"
        isTimeExercise = false
        exerciseNr = 5
        isKinectExercise = false
        isTimerExercise = true
        equipmentChoice = 1
        pickerArray = Array(0...200)
        self.performSegue(withIdentifier: "showInteger", sender: self)
        
    }
    @objc func exerciseButtonPressed6() { // Jonglera mot vägg. Fötter
        activeEquipments = activeEquipmentsArray[5]
        shouldChangeEquipment = [false,false,false,false]
        nrOfAttempts = 3
        exerciseTitle = "Jonglera mot vägg"
        isTimeExercise = false
        exerciseNr = 6
        isKinectExercise = false
        isTimerExercise = false
        equipmentChoice = 2
        pickerArray = Array(0...30)
        self.performSegue(withIdentifier: "showInteger", sender: self)
    }
    @objc func exerciseButtonPressed7() { // Kanonen. Klubba
        exerciseTitle = "Kanonen"
        activeEquipments = activeEquipmentsArray[6]
        shouldChangeEquipment = [false,false,false,false]
        equipmentChoice = 4
        nrOfAttempts = 1
        exerciseNr = 7
        isTimerExercise = false
        pickerArray = Array(0...30)
        self.performSegue(withIdentifier: "showInteger", sender: self)
    }
    @objc func exerciseButtonPressed8() {
        exerciseTitle = "Jonglera med knä"
        activeEquipments = activeEquipmentsArray[7]
        shouldChangeEquipment = [false,true,false,false]
        nrOfAttempts = 3
        exerciseNr = 8
        isTimerExercise = false
        equipmentChoice = 2
        pickerArray = Array(0...40)
        self.performSegue(withIdentifier: "showInteger", sender: self)
    }
    @objc func exerciseButtonPressed9() { // Studsa basket. Händer
        activeEquipments = activeEquipmentsArray[8]
        shouldChangeEquipment = [false,false,false,false]
        nrOfAttempts = 2
        exerciseTitle = "Studsa basket"
        //isTimeExercise = true
        exerciseNr = 9
        isTimerExercise = true
        equipmentChoice = 1
        pickerArray = Array(0...200)
        self.performSegue(withIdentifier: "showInteger", sender: self)
    }
    @objc func exerciseButtonPressed10() { // Balansera bollen. Bat
        activeEquipments = activeEquipmentsArray[9]
        shouldChangeEquipment = [false,false,true,false]
        nrOfAttempts = 3
        exerciseTitle = "Balansera bollen"
        isTimeExercise = true
        exerciseNr = 10
        isKinectExercise = false
        isTimerExercise = false
        isBalanceBall = true
        equipmentChoice = 3
        self.performSegue(withIdentifier: "showExercise", sender: self)
    }
    @objc func exerciseButtonPressed11() { // Minigolf. Klubba
        exerciseTitle = "Minigolf"
        activeEquipments = activeEquipmentsArray[10]
        shouldChangeEquipment = [false,false,false,false]
        nrOfAttempts = 6
        exerciseNr = 11
        equipmentChoice = 4
        isMiniGolf = true
        isTimerExercise = false
        pickerArray = Array(0...3)
        self.performSegue(withIdentifier: "showInteger", sender: self)
    }
        //func exerciseButtonPressed18() {
        //self.activeMenuWindow = 4
    //}
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if (segue.identifier == "showExercise") {
            let vc_ny = (segue.destination as! ExerciseViewController)
            vc_ny.nrOfAttempts = self.nrOfAttempts
            vc_ny.activeEquipments = self.activeEquipments
            vc_ny.equipmentChoice = self.equipmentChoice
            vc_ny.exerciseTitleVar = self.exerciseTitle
            vc_ny.isTimeExercise = self.isTimeExercise
            vc_ny.exerciseNr = self.exerciseNr
            vc_ny.isKinectExercise = self.isKinectExercise
            vc_ny.host = self.host
            vc_ny.nameID = self.nameID
            vc_ny.activeMenuWindow = self.activeMenuWindow
            vc_ny.idArray = self.idArray![self.exerciseNr!-1]
            vc_ny.shouldChangeEquipment = self.shouldChangeEquipment
            vc_ny.isDropBall = self.isDropBall
            vc_ny.isFastTurns = self.isFastTurns
            vc_ny.isBalanceBall = self.isBalanceBall
            
        } else if (segue.identifier == "showBoolean") {
            let vc_ny = (segue.destination as! BooleanViewController)
            vc_ny.exerciseTitleVar = self.exerciseTitle
            vc_ny.activeEquipments = self.activeEquipments
            vc_ny.nameID = self.nameID
            vc_ny.equipmentChoice = self.equipmentChoice
            vc_ny.exerciseNr = self.exerciseNr
            vc_ny.host = self.host
            vc_ny.nrOfAttempts = self.nrOfAttempts
            vc_ny.activeMenuWindow = self.activeMenuWindow
            vc_ny.idArray = self.idArray![self.exerciseNr!-1]
            vc_ny.shouldChangeEquipment = self.shouldChangeEquipment
            vc_ny.isMiniGolf = self.isMiniGolf
            
        } else if (segue.identifier == "showInteger") {
            let vc_ny = (segue.destination as! IntegerViewController)
            vc_ny.exerciseTitleVar = self.exerciseTitle
            vc_ny.activeEquipments = self.activeEquipments
            vc_ny.nameID = self.nameID
            vc_ny.equipmentChoice = self.equipmentChoice
            vc_ny.exerciseNr = self.exerciseNr
            vc_ny.host = self.host
            vc_ny.nrOfAttempts = self.nrOfAttempts
            vc_ny.activeMenuWindow = self.activeMenuWindow
            vc_ny.isTimerExcercise = self.isTimerExercise
            vc_ny.idArray = self.idArray![self.exerciseNr!-1]
            vc_ny.pickerArray = self.pickerArray
            vc_ny.shouldChangeEquipment = self.shouldChangeEquipment
            vc_ny.isMiniGolf = self.isMiniGolf
            
        }
        
    }
    
    
    
    func makeLayout() {
        
        UIApplication.shared.statusBarStyle = .lightContent
        
        
        var frame0 = vc0.view.frame
        frame0.size = self.view.frame.size
        vc0.view.frame = frame0
        
        self.addChildViewController(vc0)
        self.scrollView.addSubview(vc0.view)
        vc0.didMove(toParentViewController: self)
        
        
        var frame1 = vc1.view.frame
        frame1.origin.x = self.view.frame.size.width // * frame number
        frame1.size = self.view.frame.size
        vc1.view.frame = frame1
        
        self.addChildViewController(vc1)
        self.scrollView.addSubview(vc1.view)
        vc1.didMove(toParentViewController: self)
        
        
        var frame2 = vc2.view.frame
        frame2.origin.x = self.view.frame.size.width * 2 // * frame number
        frame2.size = self.view.frame.size
        vc2.view.frame = frame2
        
        self.addChildViewController(vc2)
        self.scrollView.addSubview(vc2.view)
        vc2.didMove(toParentViewController: self)
        
        
        var frame3 = vc3.view.frame
        frame3.origin.x = self.view.frame.size.width * 3 // * frame number
        frame3.size = self.view.frame.size
        vc3.view.frame = frame3
        
        self.addChildViewController(vc3)
        self.scrollView.addSubview(vc3.view)
        vc3.didMove(toParentViewController: self)
        
        var frame4 = vc4.view.frame
        frame4.origin.x = self.view.frame.size.width * 4 // * frame number
        frame4.size = self.view.frame.size
        vc4.view.frame = frame4
        
        self.addChildViewController(vc4)
        self.scrollView.addSubview(vc4.view)
        vc4.didMove(toParentViewController: self)
        
        self.scrollView.contentSize = CGSize(width: self.view.frame.size.width * 5, height: self.view.frame.size.height - 22) // * number of pages
        self.scrollView.contentOffset.x = CGFloat(Float(self.view.frame.size.width) * Float(activeMenuWindow))
        
    }
    
    func setUpScroll() {
        scrollView.showsHorizontalScrollIndicator = false
        scrollView.showsVerticalScrollIndicator = false
        scrollView.isPagingEnabled = true
        scrollView.bounces = false
        scrollView.delegate = self
    }
    
    func scrollViewWillEndDragging(_ scrollView: UIScrollView, withVelocity velocity: CGPoint, targetContentOffset: UnsafeMutablePointer<CGPoint>) {
        let pageNumber = pageControl.currentPage
        if pageControl.currentPage == 1 && ((velocity.x < 0.0 && scrollView.contentOffset.x < self.view.frame.width) || (scrollView.contentOffset.x < self.view.frame.width/2 && velocity.x == 0.0)) {
            UIView.animate(withDuration: 0.05, animations: {
                self.pageControl.alpha = 0
            })
        }
        if (velocity.x > 0.0 && scrollView.contentOffset.x > CGFloat(pageNumber)*self.view.frame.width) || (velocity.x == 0.0 && scrollView.contentOffset.x > self.view.frame.width*(0.5+CGFloat(pageNumber))) {
            pageControl.currentPage = pageNumber + 1
        }
        if (velocity.x < 0.0 && scrollView.contentOffset.x < CGFloat(pageNumber)*self.view.frame.width) || (velocity.x == 0.0 && scrollView.contentOffset.x < self.view.frame.width*(CGFloat(pageNumber)-0.5)) {
            pageControl.currentPage = pageNumber - 1
        }
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let pageNumber = Int(round(scrollView.contentOffset.x/scrollView.frame.size.width))
        self.activeMenuWindow = pageNumber
        pageControl.currentPage = pageNumber
        if pageNumber == 0 {
            self.pageControl.alpha = 0
        } else if pageNumber > 0 && pageControl.alpha == 0 {
            UIView.animate(withDuration: 0.2, animations: {
                self.pageControl.alpha = 1
            })
        }
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

